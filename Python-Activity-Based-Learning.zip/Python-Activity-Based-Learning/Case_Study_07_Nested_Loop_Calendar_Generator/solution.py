# Case Study 7 (PDF #37): Nested Loop Calendar Generator
# Syllabus Concepts: Nested Loops, Conditionals, Strings, Tuples, Operators, Alignment

month_label = input("Enter Month and Year label (e.g., October 2026): ").strip()
start_day = input("Enter starting weekday (MON/TUE/WED/THU/FRI/SAT/SUN): ").strip().upper()
num_days = int(input("Enter number of days in month (28 to 31): "))

weekdays = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")

start_offset = -1
for i in range(len(weekdays)):
    if weekdays[i] == start_day:
        start_offset = i
        break

print("\n======================================================================")
print("                  NESTED LOOP CALENDAR GENERATOR                      ")
print("======================================================================")

if start_offset == -1:
    print("Validation Error: Starting weekday must be one of MON, TUE, WED, THU, FRI, SAT, SUN.")
elif num_days < 28 or num_days > 31:
    print("Validation Error: Number of days must be a valid month length (28, 29, 30, or 31).")
else:
    print("Calendar :", month_label, "| Starts On:", start_day, "| Days:", num_days)
    print("----------------------------------------------------------------------")

    header_line = ""
    for d_name in weekdays:
        header_line = header_line + format(d_name, ">4s") + " "
    print(header_line.rstrip())
    print("----------------------------------")

    total_cells = start_offset + num_days
    total_weeks = (total_cells + 6) // 7
    current_day = 1

    # Outer loop for weeks, inner loop for 7 days of the week
    for week in range(total_weeks):
        row_str = ""
        for col in range(7):
            cell_index = (week * 7) + col
            if cell_index < start_offset or current_day > num_days:
                row_str = row_str + "     "
            else:
                row_str = row_str + format(current_day, "4d") + " "
                current_day = current_day + 1
        print(row_str.rstrip())

    print("----------------------------------------------------------------------")
    print("Total Calendar Rows (Weeks) Rendered:", total_weeks)
print("======================================================================")
