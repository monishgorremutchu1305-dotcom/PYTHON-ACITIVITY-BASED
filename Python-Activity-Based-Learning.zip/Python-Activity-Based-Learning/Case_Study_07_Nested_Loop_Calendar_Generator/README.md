# Case Study 07 (PDF #37): Nested Loop Monthly Calendar Generator


**Assigned Syllabus Concepts Used:** Nested Loops, Tuple Lookup, Integer Division, Tabular String Alignment

---

## 1. Problem Statement

> **PDF Prompt (#37):** 37. Nested Loop Calendar Generator: Generate a formatted monthly calendar using the supplied starting weekday and number of days, correctly aligning weeks and handling valid month lengths.

Generating a printable monthly wall calendar without built-in `calendar` or `datetime` modules requires mapping linear day numbers onto a 2D week-by-weekday matrix. Given a month title, a starting weekday code (`MON` through `SUN`), and the number of days in the month (`28` to `31`), the program validates both inputs, calculates leading blank weekday offsets, determines the exact number of week rows via ceiling division, and prints right-aligned columns using nested loops.

---

## 2. Objectives

1. Validate weekday abbreviations against a constant 7-element tuple and verify valid calendar month lengths (28–31 days).
2. Compute initial weekday column offset (`0` for `MON` through `6` for `SUN`) and ceiling week count `(offset + num_days + 6) // 7`.
3. Render aligned 7-column weekly rows using an outer `week` loop and inner `col` loop without importing Python’s `calendar` module.
4. Handle 4-week, 5-week, and 6-week spanning months accurately (such as a 31-day month starting on `SUN`).

---

## 3. Assumptions

- Weeks follow ISO Monday-first ordering (`MON`, `TUE`, `WED`, `THU`, `FRI`, `SAT`, `SUN`).
- Valid month lengths are strictly integers `28`, `29` (leap February), `30`, or `31`.
- Each day column occupies 4 right-aligned characters followed by a single space separator.
- No built-in `calendar` or `datetime` library imports are used.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read `month_label`, `start_day` (uppercase), and integer `num_days`.
- **Step 3:** Define `weekdays = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")` and locate `start_offset` via linear loop.
- **Step 4:** If `start_offset == -1` or `num_days < 28` or `num_days > 31`, print specific validation error and jump to Step 9.
- **Step 5:** Print calendar banner and 7-column weekday header.
- **Step 6:** Calculate `total_cells = start_offset + num_days` and `total_weeks = (total_cells + 6) // 7`. Set `current_day = 1`.
- **Step 7:** Outer loop `week` from `0` to `total_weeks - 1`; inner loop `col` from `0` to `6`: compute `cell_index = week * 7 + col`.
- **Step 8:** If `cell_index < start_offset` or `current_day > num_days`, append 5 spaces; else append `format(current_day, "4d") + " "` and increment `current_day`. Print each completed week row.
- **Step 9:** Stop the program.

---

## 5. Flowchart

![Flowchart - Nested Loop Monthly Calendar Generator](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT month_label, start_day, num_days
    SET weekdays = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")
    FIND start_offset OF start_day IN weekdays (OR -1 IF NOT FOUND)

    IF start_offset == -1 THEN
        PRINT "Validation Error: Invalid starting weekday"
    ELSE IF num_days < 28 OR num_days > 31 THEN
        PRINT "Validation Error: Invalid month length"
    ELSE
        PRINT month_label, weekday header
        SET total_weeks = (start_offset + num_days + 6) DIV 7
        SET current_day = 1

        FOR week = 0 TO total_weeks - 1 DO
            SET row_str = ""
            FOR col = 0 TO 6 DO
                SET cell_index = (week * 7) + col
                IF cell_index < start_offset OR current_day > num_days THEN
                    CONCAT "     " TO row_str
                ELSE
                    CONCAT FORMAT(current_day, "4d") + " " TO row_str
                    INCREMENT current_day
                END IF
            END FOR
            PRINT RSTRIP(row_str)
        END FOR
    END IF
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 7 (PDF #37): Nested Loop Calendar Generator
# Syllabus Concepts: Nested Loops, Conditionals, Strings, Tuples, Operators, Alignment

month_label = input("Enter Month and Year label (e.g., October 2026): ").strip()
start_day = input("Enter starting weekday (MON/TUE/WED/THU/FRI/SAT/SUN): ").strip().upper()
num_days = int(input("Enter number of days in month (28 to 31): "))

weekdays = ("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")

start_offset = -1
for i in range(len(weekdays)):
    if weekdays[i] == start_day:
        start_offset = i
        break

print("\n======================================================================")
print("                  NESTED LOOP CALENDAR GENERATOR                      ")
print("======================================================================")

if start_offset == -1:
    print("Validation Error: Starting weekday must be one of MON, TUE, WED, THU, FRI, SAT, SUN.")
elif num_days < 28 or num_days > 31:
    print("Validation Error: Number of days must be a valid month length (28, 29, 30, or 31).")
else:
    print("Calendar :", month_label, "| Starts On:", start_day, "| Days:", num_days)
    print("----------------------------------------------------------------------")

    header_line = ""
    for d_name in weekdays:
        header_line = header_line + format(d_name, ">4s") + " "
    print(header_line.rstrip())
    print("----------------------------------")

    total_cells = start_offset + num_days
    total_weeks = (total_cells + 6) // 7
    current_day = 1

    # Outer loop for weeks, inner loop for 7 days of the week
    for week in range(total_weeks):
        row_str = ""
        for col in range(7):
            cell_index = (week * 7) + col
            if cell_index < start_offset or current_day > num_days:
                row_str = row_str + "     "
            else:
                row_str = row_str + format(current_day, "4d") + " "
                current_day = current_day + 1
        print(row_str.rstrip())

    print("----------------------------------------------------------------------")
    print("Total Calendar Rows (Weeks) Rendered:", total_weeks)
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | October 2026 (31 days starting on Thursday -> 5 aligned weeks) | `October 2026<br>THU<br>31` | Leaves MON–WED blank on Week 1, aligns 1 under THU, wraps cleanly across 5 rows ending Saturday 31. | PASS |
| **TC-02** (Boundary / Tie) | Maximum 6-week span (31 days starting on Sunday) | `March 2026<br>SUN<br>31` | Correctly expands to 6 calendar rows because offset 6 + 31 days = 37 cells. | PASS |
| **TC-03** (Edge / Validation) | Invalid 32-day month length rejected by boundary validator | `InvalidMonth 2026<br>MON<br>32` | Rejects 32 days immediately with clear month-length error message. | PASS |

---

## 9. Output Screenshots

### TC-01: October 2026 (31 days starting on Thursday -> 5 aligned weeks) (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter Month and Year label (e.g., October 2026): October 2026
Enter starting weekday (MON/TUE/WED/THU/FRI/SAT/SUN): THU
Enter number of days in month (28 to 31): 31

======================================================================
                  NESTED LOOP CALENDAR GENERATOR                      
======================================================================
Calendar : October 2026 | Starts On: THU | Days: 31
----------------------------------------------------------------------
 MON  TUE  WED  THU  FRI  SAT  SUN
----------------------------------
                  1    2    3    4
   5    6    7    8    9   10   11
  12   13   14   15   16   17   18
  19   20   21   22   23   24   25
  26   27   28   29   30   31
----------------------------------------------------------------------
Total Calendar Rows (Weeks) Rendered: 5
======================================================================
```
</details>

### TC-02: Maximum 6-week span (31 days starting on Sunday) (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter Month and Year label (e.g., October 2026): March 2026
Enter starting weekday (MON/TUE/WED/THU/FRI/SAT/SUN): SUN
Enter number of days in month (28 to 31): 31

======================================================================
                  NESTED LOOP CALENDAR GENERATOR                      
======================================================================
Calendar : March 2026 | Starts On: SUN | Days: 31
----------------------------------------------------------------------
 MON  TUE  WED  THU  FRI  SAT  SUN
----------------------------------
                                 1
   2    3    4    5    6    7    8
   9   10   11   12   13   14   15
  16   17   18   19   20   21   22
  23   24   25   26   27   28   29
  30   31
----------------------------------------------------------------------
Total Calendar Rows (Weeks) Rendered: 6
======================================================================
```
</details>

### TC-03: Invalid 32-day month length rejected by boundary validator (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter Month and Year label (e.g., October 2026): InvalidMonth 2026
Enter starting weekday (MON/TUE/WED/THU/FRI/SAT/SUN): MON
Enter number of days in month (28 to 31): 32

======================================================================
                  NESTED LOOP CALENDAR GENERATOR                      
======================================================================
Validation Error: Number of days must be a valid month length (28, 29, 30, or 31).
======================================================================
```
</details>

---

## 10. Conclusion

Nested Loop Calendar Generator showcases 2D grid indexing (`week * 7 + col`), tuple lookup, ceiling integer division, and tabular string formatting to construct accurate monthly calendars across all weekday and leap-year combinations.
