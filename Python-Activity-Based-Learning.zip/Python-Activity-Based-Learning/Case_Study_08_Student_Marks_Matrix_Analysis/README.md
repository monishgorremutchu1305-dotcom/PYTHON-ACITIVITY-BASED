# Case Study 08 (PDF #42): Student Marks Matrix Analysis


**Assigned Syllabus Concepts Used:** Nested Lists (2D Matrix), Row & Column Traversal, Statistical Aggregation, Tuples & Unpacking

---

## 1. Problem Statement

> **PDF Prompt (#42):** 42. Student Marks Matrix Analysis: Analyse a matrix of student marks across subjects, calculate row-wise and column-wise statistics, identify top performers, and detect subjects with low average performance.

Academic departments store cohort examination scores as a two-dimensional matrix where rows represent students and columns represent subjects. Analysing this matrix along both axes provides dual insights: row-wise aggregation computes each student’s total, average, minimum, and maximum scores to identify cohort top performers (including ties), while column-wise aggregation computes class averages, highs, and lows per subject to flag subjects falling below a department quality benchmark.

---

## 2. Objectives

1. Construct a 2D nested list `marks_matrix[student][subject]` paired with student metadata tuples.
2. Perform row-wise nested loop traversal to compute student totals, averages, extremes, and tied top performers.
3. Perform column-wise nested loop traversal (`marks_matrix[r][c]`) to compute subject averages, highs, and lows.
4. Flag subjects whose class average falls strictly below the supplied performance threshold.

---

## 3. Assumptions

- Number of students `M >= 1` and number of subjects `K >= 1`, with marks on a 0–100 scale.
- Each input line provides `RollNo, Name` followed by `K` comma-separated subject scores.
- If multiple students share the highest aggregate average (rounded to 2 decimal places), all tied students are recognized as Top Performers.
- Any subject with column average `< low_avg_threshold` is flagged for academic intervention.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read `num_students`, comma-separated `subjects`, and `low_avg_threshold`.
- **Step 3:** Initialize `students_info = []` and 2D list `marks_matrix = []`. Loop `num_students` times to append `(roll_no, name)` and `row_marks` list.
- **Step 4:** Row-wise pass: for each row `r` from `0` to `num_students - 1`, sum `marks_matrix[r][c]`, find `row_min` and `row_max`, compute `row_avg`, and track maximum `top_average`.
- **Step 5:** Display row-wise performance table for all students.
- **Step 6:** Column-wise pass: for each column `c` from `0` to `num_subjects - 1`, sum `marks_matrix[r][c]` across all rows `r`, find `col_min`, `col_max`, and `col_avg`.
- **Step 7:** If `col_avg < low_avg_threshold`, mark subject as `LOW AVERAGE` and append `(subjects[c], col_avg)` to `low_subjects`.
- **Step 8:** Display column-wise subject table, print all students matching `top_average`, and list flagged low-average subjects.
- **Step 9:** Stop the program.

---

## 5. Flowchart

![Flowchart - Student Marks Matrix Analysis](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT num_students, subjects_list, low_avg_threshold
    SET students_info = [], marks_matrix = []

    FOR i = 0 TO num_students - 1 DO
        INPUT roll_no, name, row_marks[0..K-1]
        APPEND (roll_no, name) TO students_info
        APPEND row_marks TO marks_matrix
    END FOR

    SET top_average = -1.0, student_stats = []
    FOR r = 0 TO num_students - 1 DO
        Compute row_total, row_min, row_max across c = 0..K-1
        SET row_avg = row_total / K
        IF row_avg > top_average THEN SET top_average = row_avg END IF
        APPEND (roll_no, name, row_total, row_avg, row_min, row_max) TO student_stats
    END FOR

    SET low_subjects = []
    FOR c = 0 TO K - 1 DO
        Compute col_total, col_min, col_max across r = 0..num_students-1
        SET col_avg = col_total / num_students
        IF col_avg < low_avg_threshold THEN
            APPEND (subjects_list[c], col_avg) TO low_subjects
        END IF
    END FOR

    PRINT student_stats, subject_stats, top_performers, low_subjects
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 8 (PDF #42): Student Marks Matrix Analysis
# Syllabus Concepts: Nested Lists (2D Matrix), Loops, Conditionals, Tuples, Unpacking

num_students = int(input("Enter number of students: "))
subjects_raw = input("Enter comma-separated subject names: ").strip()
low_avg_threshold = float(input("Enter low-performance subject average threshold: "))

subjects = []
for s in subjects_raw.split(","):
    subjects.append(s.strip())

num_subjects = len(subjects)
students_info = []
marks_matrix = []

for i in range(num_students):
    raw = input("Enter RollNo,Name followed by marks: ").strip()
    parts = raw.split(",")
    roll_no = parts[0].strip()
    name = parts[1].strip()
    students_info.append((roll_no, name))

    row_marks = []
    for j in range(num_subjects):
        score = float(parts[2 + j].strip())
        row_marks.append(score)
    marks_matrix.append(row_marks)

print("\n======================================================================")
print("                   STUDENT MARKS MATRIX ANALYSIS                      ")
print("======================================================================")

# Row-wise statistics (Student totals, averages, and top performer identification)
student_stats = []
top_average = -1.0

for r in range(num_students):
    roll_no, name = students_info[r]
    row_total = 0.0
    row_min = marks_matrix[r][0]
    row_max = marks_matrix[r][0]

    for c in range(num_subjects):
        val = marks_matrix[r][c]
        row_total = row_total + val
        if val < row_min:
            row_min = val
        if val > row_max:
            row_max = val

    row_avg = row_total / num_subjects
    if row_avg > top_average:
        top_average = row_avg

    student_stats.append((roll_no, name, row_total, row_avg, row_min, row_max))

print("ROW-WISE STUDENT PERFORMANCE:")
for stat in student_stats:
    r_no, s_name, tot, avg, mn, mx = stat
    print(r_no, "|", format(s_name, "<14s"), "| Total:", format(tot, "6.1f"), "| Avg:", format(avg, "5.2f") + "%", "| Min:", format(mn, "4.0f"), "| Max:", format(mx, "4.0f"))

# Column-wise statistics (Subject averages, highest, lowest, low-average detection)
print("----------------------------------------------------------------------")
print("COLUMN-WISE SUBJECT STATISTICS:")
low_subjects = []

for c in range(num_subjects):
    col_total = 0.0
    col_min = marks_matrix[0][c]
    col_max = marks_matrix[0][c]

    for r in range(num_students):
        val = marks_matrix[r][c]
        col_total = col_total + val
        if val < col_min:
            col_min = val
        if val > col_max:
            col_max = val

    col_avg = col_total / num_students
    flag = "Satisfactory"
    if col_avg < low_avg_threshold:
        flag = "LOW AVERAGE (<" + format(low_avg_threshold, ".1f") + ")"
        low_subjects.append((subjects[c], col_avg))

    print(format(subjects[c], "<14s"), "| Class Avg:", format(col_avg, "5.2f"), "| High:", format(col_max, "5.1f"), "| Low:", format(col_min, "5.1f"), "|", flag)

print("----------------------------------------------------------------------")
print("TOP PERFORMER(S):")
for stat in student_stats:
    r_no, s_name, tot, avg, mn, mx = stat
    if round(avg, 2) == round(top_average, 2):
        print(" ->", r_no, "-", s_name, "with Aggregate", format(avg, ".2f") + "%")

if len(low_subjects) == 0:
    print("Subjects Needing Attention: None")
else:
    alert_text = ""
    for k in range(len(low_subjects)):
        sub_n, sub_a = low_subjects[k]
        if k > 0:
            alert_text = alert_text + ", "
        alert_text = alert_text + sub_n + " (" + format(sub_a, ".2f") + ")"
    print("Subjects Needing Attention:", alert_text)
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | 3x4 Cohort Matrix with tied top performers and Physics below 65% threshold | `3<br>Python,Maths,Physics,DSA<br>65<br>24CS01,Ananya Rao,92,88,64,92<br>24CS02,Karthik M,78,62,52,70<br>24CS03,Meera Das,90,86,64,96` | Identifies tied top performers Ananya Rao & Meera Das (84.00%) and flags Physics (Class Avg 60.00 < 65.0). | PASS |
| **TC-02** (Boundary / Tie) | All subjects meeting exact 70.0 threshold boundary | `2<br>OS,DBMS<br>70<br>24CS11,Arjun Nair,70,80<br>24CS12,Divya Menon,70,90` | OS class average = 70.00 (not < 70.0), so zero subjects flagged; Divya Menon tops at 80.00%. | PASS |
| **TC-03** (Edge / Validation) | Single-student matrix across 3 subjects with multiple low-performing subjects | `1<br>Calculus,Chemistry,C_Lab<br>60<br>24CS99,Rohan Roy,54,48,88` | Handles 1x3 matrix cleanly and flags both Calculus (54.00) and Chemistry (48.00). | PASS |

---

## 9. Output Screenshots

### TC-01: 3x4 Cohort Matrix with tied top performers and Physics below 65% threshold (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter number of students: 3
Enter comma-separated subject names: Python,Maths,Physics,DSA
Enter low-performance subject average threshold: 65
Enter RollNo,Name followed by marks: 24CS01,Ananya Rao,92,88,64,92
Enter RollNo,Name followed by marks: 24CS02,Karthik M,78,62,52,70
Enter RollNo,Name followed by marks: 24CS03,Meera Das,90,86,64,96

======================================================================
                   STUDENT MARKS MATRIX ANALYSIS                      
======================================================================
ROW-WISE STUDENT PERFORMANCE:
24CS01 | Ananya Rao     | Total:  336.0 | Avg: 84.00% | Min:   64 | Max:   92
24CS02 | Karthik M      | Total:  262.0 | Avg: 65.50% | Min:   52 | Max:   78
24CS03 | Meera Das      | Total:  336.0 | Avg: 84.00% | Min:   64 | Max:   96
----------------------------------------------------------------------
COLUMN-WISE SUBJECT STATISTICS:
Python         | Class Avg: 86.67 | High:  92.0 | Low:  78.0 | Satisfactory
Maths          | Class Avg: 78.67 | High:  88.0 | Low:  62.0 | Satisfactory
Physics        | Class Avg: 60.00 | High:  64.0 | Low:  52.0 | LOW AVERAGE (<65.0)
DSA            | Class Avg: 86.00 | High:  96.0 | Low:  70.0 | Satisfactory
----------------------------------------------------------------------
TOP PERFORMER(S):
 -> 24CS01 - Ananya Rao with Aggregate 84.00%
 -> 24CS03 - Meera Das with Aggregate 84.00%
Subjects Needing Attention: Physics (60.00)
======================================================================
```
</details>

### TC-02: All subjects meeting exact 70.0 threshold boundary (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter number of students: 2
Enter comma-separated subject names: OS,DBMS
Enter low-performance subject average threshold: 70
Enter RollNo,Name followed by marks: 24CS11,Arjun Nair,70,80
Enter RollNo,Name followed by marks: 24CS12,Divya Menon,70,90

======================================================================
                   STUDENT MARKS MATRIX ANALYSIS                      
======================================================================
ROW-WISE STUDENT PERFORMANCE:
24CS11 | Arjun Nair     | Total:  150.0 | Avg: 75.00% | Min:   70 | Max:   80
24CS12 | Divya Menon    | Total:  160.0 | Avg: 80.00% | Min:   70 | Max:   90
----------------------------------------------------------------------
COLUMN-WISE SUBJECT STATISTICS:
OS             | Class Avg: 70.00 | High:  70.0 | Low:  70.0 | Satisfactory
DBMS           | Class Avg: 85.00 | High:  90.0 | Low:  80.0 | Satisfactory
----------------------------------------------------------------------
TOP PERFORMER(S):
 -> 24CS12 - Divya Menon with Aggregate 80.00%
Subjects Needing Attention: None
======================================================================
```
</details>

### TC-03: Single-student matrix across 3 subjects with multiple low-performing subjects (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter number of students: 1
Enter comma-separated subject names: Calculus,Chemistry,C_Lab
Enter low-performance subject average threshold: 60
Enter RollNo,Name followed by marks: 24CS99,Rohan Roy,54,48,88

======================================================================
                   STUDENT MARKS MATRIX ANALYSIS                      
======================================================================
ROW-WISE STUDENT PERFORMANCE:
24CS99 | Rohan Roy      | Total:  190.0 | Avg: 63.33% | Min:   48 | Max:   88
----------------------------------------------------------------------
COLUMN-WISE SUBJECT STATISTICS:
Calculus       | Class Avg: 54.00 | High:  54.0 | Low:  54.0 | LOW AVERAGE (<60.0)
Chemistry      | Class Avg: 48.00 | High:  48.0 | Low:  48.0 | LOW AVERAGE (<60.0)
C_Lab          | Class Avg: 88.00 | High:  88.0 | Low:  88.0 | Satisfactory
----------------------------------------------------------------------
TOP PERFORMER(S):
 -> 24CS99 - Rohan Roy with Aggregate 63.33%
Subjects Needing Attention: Calculus (54.00), Chemistry (48.00)
======================================================================
```
</details>

---

## 10. Conclusion

Student Marks Matrix Analysis demonstrates orthogonal row-wise and column-wise traversal over nested lists without NumPy or external packages, accurately computing cohort rankings and pinpointing weak subjects.
