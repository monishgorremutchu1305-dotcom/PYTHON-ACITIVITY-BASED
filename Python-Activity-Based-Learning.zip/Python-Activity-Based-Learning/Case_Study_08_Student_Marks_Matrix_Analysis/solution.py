# Case Study 8 (PDF #42): Student Marks Matrix Analysis
# Syllabus Concepts: Nested Lists (2D Matrix), Loops, Conditionals, Tuples, Unpacking

num_students = int(input("Enter number of students: "))
subjects_raw = input("Enter comma-separated subject names: ").strip()
low_avg_threshold = float(input("Enter low-performance subject average threshold: "))

subjects = []
for s in subjects_raw.split(","):
    subjects.append(s.strip())

num_subjects = len(subjects)
students_info = []
marks_matrix = []

for i in range(num_students):
    raw = input("Enter RollNo,Name followed by marks: ").strip()
    parts = raw.split(",")
    roll_no = parts[0].strip()
    name = parts[1].strip()
    students_info.append((roll_no, name))

    row_marks = []
    for j in range(num_subjects):
        score = float(parts[2 + j].strip())
        row_marks.append(score)
    marks_matrix.append(row_marks)

print("\n======================================================================")
print("                   STUDENT MARKS MATRIX ANALYSIS                      ")
print("======================================================================")

# Row-wise statistics (Student totals, averages, and top performer identification)
student_stats = []
top_average = -1.0

for r in range(num_students):
    roll_no, name = students_info[r]
    row_total = 0.0
    row_min = marks_matrix[r][0]
    row_max = marks_matrix[r][0]

    for c in range(num_subjects):
        val = marks_matrix[r][c]
        row_total = row_total + val
        if val < row_min:
            row_min = val
        if val > row_max:
            row_max = val

    row_avg = row_total / num_subjects
    if row_avg > top_average:
        top_average = row_avg

    student_stats.append((roll_no, name, row_total, row_avg, row_min, row_max))

print("ROW-WISE STUDENT PERFORMANCE:")
for stat in student_stats:
    r_no, s_name, tot, avg, mn, mx = stat
    print(r_no, "|", format(s_name, "<14s"), "| Total:", format(tot, "6.1f"), "| Avg:", format(avg, "5.2f") + "%", "| Min:", format(mn, "4.0f"), "| Max:", format(mx, "4.0f"))

# Column-wise statistics (Subject averages, highest, lowest, low-average detection)
print("----------------------------------------------------------------------")
print("COLUMN-WISE SUBJECT STATISTICS:")
low_subjects = []

for c in range(num_subjects):
    col_total = 0.0
    col_min = marks_matrix[0][c]
    col_max = marks_matrix[0][c]

    for r in range(num_students):
        val = marks_matrix[r][c]
        col_total = col_total + val
        if val < col_min:
            col_min = val
        if val > col_max:
            col_max = val

    col_avg = col_total / num_students
    flag = "Satisfactory"
    if col_avg < low_avg_threshold:
        flag = "LOW AVERAGE (<" + format(low_avg_threshold, ".1f") + ")"
        low_subjects.append((subjects[c], col_avg))

    print(format(subjects[c], "<14s"), "| Class Avg:", format(col_avg, "5.2f"), "| High:", format(col_max, "5.1f"), "| Low:", format(col_min, "5.1f"), "|", flag)

print("----------------------------------------------------------------------")
print("TOP PERFORMER(S):")
for stat in student_stats:
    r_no, s_name, tot, avg, mn, mx = stat
    if round(avg, 2) == round(top_average, 2):
        print(" ->", r_no, "-", s_name, "with Aggregate", format(avg, ".2f") + "%")

if len(low_subjects) == 0:
    print("Subjects Needing Attention: None")
else:
    alert_text = ""
    for k in range(len(low_subjects)):
        sub_n, sub_a = low_subjects[k]
        if k > 0:
            alert_text = alert_text + ", "
        alert_text = alert_text + sub_n + " (" + format(sub_a, ".2f") + ")"
    print("Subjects Needing Attention:", alert_text)
print("======================================================================")
