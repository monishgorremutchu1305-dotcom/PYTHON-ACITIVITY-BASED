# Case Study 10 (PDF #49): Tuple-Based Product Catalogue Audit
# Syllabus Concepts: Tuples, Tuple Operations, Unpacking, Lists, Loops, Conditionals, Operators

num_items = int(input("Enter number of catalogue records: "))
reorder_threshold = int(input("Enter minimum stock reorder threshold: "))

catalogue = []
for i in range(num_items):
    raw = input("Enter ProductID,ProductName,UnitPrice,StockQty: ").strip()
    parts = raw.split(",")
    prod_id = parts[0].strip()
    prod_name = parts[1].strip()
    price = float(parts[2].strip())
    qty = int(parts[3].strip())

    # Store each product record as a tuple
    catalogue.append((prod_id, prod_name, price, qty))

seen_ids = []
valid_items = []
invalid_records = []
replenish_items = []
total_inventory_value = 0.0

for item in catalogue:
    # Unpack product tuple
    p_id, p_name, p_price, p_qty = item
    error_reason = ""

    # Validate Product ID format (must start with 'P' followed by digits, e.g., P101)
    if len(p_id) < 2 or p_id[0] != "P" or not p_id[1:].isdigit():
        error_reason = error_reason + "Malformed ProductID; "
    elif p_id in seen_ids:
        error_reason = error_reason + "Duplicate ProductID; "

    if p_name == "":
        error_reason = error_reason + "Empty ProductName; "
    if p_price <= 0:
        error_reason = error_reason + "Non-positive Price; "
    if p_qty < 0:
        error_reason = error_reason + "Negative StockQty; "

    if error_reason != "":
        invalid_records.append((p_id, p_name, p_price, p_qty, error_reason[:-2]))
    else:
        seen_ids.append(p_id)
        item_value = p_price * p_qty
        total_inventory_value = total_inventory_value + item_value
        valid_items.append((p_id, p_name, p_price, p_qty, item_value))

        if p_qty < reorder_threshold:
            shortfall = reorder_threshold - p_qty
            replenish_items.append((p_id, p_name, p_qty, shortfall))

print("\n======================================================================")
print("               TUPLE-BASED PRODUCT CATALOGUE AUDIT                    ")
print("======================================================================")
print("VALIDATED INVENTORY VALUATION:")
if len(valid_items) == 0:
    print("No valid product records found.")
else:
    for v_item in valid_items:
        p_id, p_name, p_price, p_qty, val = v_item
        print(p_id, "|", format(p_name, "<16s"), "| Price: Rs.", format(p_price, "8.2f"), "| Stock:", format(p_qty, "4d"), "| Value: Rs.", format(val, "10.2f"))

print("----------------------------------------------------------------------")
print("INVALID CATALOGUE RECORDS FLAGGED:")
if len(invalid_records) == 0:
    print("None")
else:
    for bad_item in invalid_records:
        p_id, p_name, p_price, p_qty, err = bad_item
        print(" ->", p_id, "|", p_name, "| Price:", p_price, "| Qty:", p_qty, "| Issue:", err)

print("----------------------------------------------------------------------")
print("ITEMS REQUIRING REPLENISHMENT (Stock <", str(reorder_threshold) + "):")
if len(replenish_items) == 0:
    print("All valid products meet minimum stock threshold.")
else:
    for rep in replenish_items:
        p_id, p_name, cur_q, needed = rep
        print(" ->", p_id, "|", p_name, "| Current Stock:", cur_q, "| Minimum Order Needed:", needed, "units")

print("----------------------------------------------------------------------")
print("Valid Products:", len(valid_items), "| Invalid Records:", len(invalid_records), "| Total Inventory Value: Rs.", format(total_inventory_value, ".2f"))
print("======================================================================")
