# Case Study 5 (PDF #29): Password Policy Validation Engine
# Syllabus Concepts: Strings, Loops, Conditionals, Lists, Tuples, Unpacking

count = int(input("Enter number of sample passwords to evaluate: "))
prohibited_words = ("password", "admin", "1234", "qwerty", "welcome")
special_chars = "!@#$%^&*()-_=+[]{}|;:,.<>?/"

results = []

for idx in range(count):
    pwd = input("Enter candidate password: ").strip()
    failures = []

    # Rule 1: Minimum length >= 8 and no spaces
    if len(pwd) < 8:
        failures.append("Length < 8 chars")

    has_upper = False
    has_lower = False
    has_digit = False
    has_special = False
    has_space = False
    has_triple_repeat = False

    for i in range(len(pwd)):
        ch = pwd[i]
        if ch.isupper():
            has_upper = True
        elif ch.islower():
            has_lower = True
        elif ch.isdigit():
            has_digit = True
        elif ch == " ":
            has_space = True
        elif ch in special_chars:
            has_special = True

        # Rule 3: No 3 consecutive identical characters (e.g., 'aaa' or '111')
        if i >= 2 and pwd[i] == pwd[i - 1] and pwd[i] == pwd[i - 2]:
            has_triple_repeat = True

    if has_space:
        failures.append("Contains whitespace")
    if not has_upper:
        failures.append("Missing uppercase letter")
    if not has_lower:
        failures.append("Missing lowercase letter")
    if not has_digit:
        failures.append("Missing numeric digit")
    if not has_special:
        failures.append("Missing special character")
    if has_triple_repeat:
        failures.append("Contains 3+ consecutive repeated chars")

    # Rule 4: Prohibited substring check (case-insensitive)
    lower_pwd = pwd.lower()
    matched_banned = ""
    for banned in prohibited_words:
        if banned in lower_pwd:
            if matched_banned == "":
                matched_banned = banned
            else:
                matched_banned = matched_banned + ", " + banned

    if matched_banned != "":
        failures.append("Contains prohibited substring (" + matched_banned + ")")

    is_valid = len(failures) == 0
    results.append((pwd, is_valid, failures))

print("\n======================================================================")
print("                 PASSWORD POLICY VALIDATION ENGINE                    ")
print("======================================================================")

valid_total = 0
for record in results:
    pwd, is_valid, fail_list = record
    if is_valid:
        valid_total = valid_total + 1
        print("[PASS] '" + pwd + "' -> Meets all security policy rules.")
    else:
        reason_str = ""
        for k in range(len(fail_list)):
            if k > 0:
                reason_str = reason_str + "; "
            reason_str = reason_str + fail_list[k]
        print("[FAIL] '" + pwd + "' -> Failed (" + str(len(fail_list)) + "): " + reason_str)

print("----------------------------------------------------------------------")
print("Summary: Evaluated =", len(results), "| Compliant =", valid_total, "| Non-Compliant =", len(results) - valid_total)
print("======================================================================")
