# Case Study 4 (PDF #27): Advanced Numeric Pattern Generator
# Syllabus Concepts: Pattern Generation, Nested Loops, Conditionals, Strings, Alignment

mode = input("Enter Pattern Mode (HOLLOW / SYMMETRIC): ").strip().upper()
size = int(input("Enter odd dimension N (3 to 19): "))

print("\n======================================================================")
print("                ADVANCED NUMERIC PATTERN GENERATOR                    ")
print("======================================================================")

if mode != "HOLLOW" and mode != "SYMMETRIC":
    print("Validation Error: Mode must be either HOLLOW or SYMMETRIC.")
elif size < 3 or size > 19 or size % 2 == 0:
    print("Validation Error: Dimension N must be an odd integer between 3 and 19.")
else:
    mid = (size // 2) + 1
    print("Mode:", mode, "| Dimension:", str(size) + "x" + str(size), "| Apex Level:", mid)
    print("----------------------------------------------------------------------")

    for row in range(1, size + 1):
        if row <= mid:
            level = row
        else:
            level = size - row + 1

        leading_spaces = mid - level
        line = ""

        # Leading spaces for careful multi-digit alignment (3 chars per cell)
        for s in range(leading_spaces):
            line = line + "   "

        width = (2 * level) - 1
        for col in range(1, width + 1):
            if mode == "HOLLOW":
                if col == 1 or col == width:
                    val_str = format(level, "2d") + " "
                    line = line + val_str
                else:
                    line = line + "   "
            else:
                # SYMMETRIC palindromic numerical diamond: 1 2 .. level .. 2 1
                if col <= level:
                    num = col
                else:
                    num = (2 * level) - col
                val_str = format(num, "2d") + " "
                line = line + val_str

        print(line.rstrip())

    print("----------------------------------------------------------------------")
    print("Pattern generation completed successfully.")
print("======================================================================")
