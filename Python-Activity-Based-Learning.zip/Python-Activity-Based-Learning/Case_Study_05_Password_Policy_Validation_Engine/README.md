# Case Study 05 (PDF #29): Password Policy Validation Engine


**Assigned Syllabus Concepts Used:** Strings & Indexing, Character Classification, Substring Membership, Loops & Lists

---

## 1. Problem Statement

> **PDF Prompt (#29):** 29. Password Policy Validation Engine: Evaluate sample password strings against minimum length, character-category, repetition, and prohibited-substring rules; explain each failed condition.

Authentication systems enforce composite password policies to defend user accounts against dictionary and brute-force attacks. Rather than returning a generic failure flag, an effective validation engine inspects every candidate password across all policy dimensions—minimum length, presence of uppercase, lowercase, digit, and special symbol categories, absence of whitespace, prevention of three or more consecutive identical characters, and blocking common dictionary substrings—reporting every failed condition clearly.

---

## 2. Objectives

1. Inspect password strings character-by-character using index-controlled loops and built-in string classification methods.
2. Detect consecutive triple character repetitions (`pwd[i] == pwd[i-1] == pwd[i-2]`) using sliding index comparisons.
3. Perform case-insensitive prohibited-substring scanning against a tuple of banned patterns (`password`, `admin`, `1234`, `qwerty`, `welcome`).
4. Accumulate and report every distinct policy violation for each tested password string.

---

## 3. Assumptions

- Minimum compliant password length is 8 characters with zero whitespace characters allowed.
- At least one uppercase letter (`A-Z`), one lowercase letter (`a-z`), one digit (`0-9`), and one special character from `!@#$%^&*()-_=+[]{}|;:,.<>?/` are mandatory.
- Three or more identical adjacent characters (e.g., `aaa` or `999`) violate the repetition rule.
- Case-insensitive containment of any prohibited token (`password`, `admin`, `1234`, `qwerty`, `welcome`) fails validation.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read number of sample passwords `count`. Define `prohibited_words` tuple and `special_chars` string.
- **Step 3:** Loop `count` times: read candidate `pwd` and initialize empty list `failures` and boolean category flags.
- **Step 4:** If `len(pwd) < 8`, append `"Length < 8 chars"` to `failures`.
- **Step 5:** Traverse `pwd` by index `i` from `0` to `len(pwd)-1`: update `has_upper`, `has_lower`, `has_digit`, `has_space`, and `has_special`; if `i >= 2` and `pwd[i] == pwd[i-1] == pwd[i-2]`, set `has_triple_repeat = True`.
- **Step 6:** Check each boolean flag and append corresponding descriptive failure strings to `failures`.
- **Step 7:** Convert `pwd` to lowercase and check membership of each word in `prohibited_words`; if any match, append prohibited substring failure.
- **Step 8:** Store `(pwd, len(failures) == 0, failures)` in `results`.
- **Step 9:** Print `[PASS]` or `[FAIL]` with detailed explanation for every evaluated password and display compliance counts.
- **Step 10:** Stop the program.

---

## 5. Flowchart

![Flowchart - Password Policy Validation Engine](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT count
    SET prohibited = ("password", "admin", "1234", "qwerty", "welcome")
    SET results = []

    FOR idx = 1 TO count DO
        INPUT pwd
        SET failures = []
        IF LENGTH(pwd) < 8 THEN APPEND "Length < 8 chars" TO failures END IF

        SET upper=FALSE, lower=FALSE, digit=FALSE, special=FALSE, space=FALSE, repeat3=FALSE
        FOR i = 0 TO LENGTH(pwd) - 1 DO
            Inspect pwd[i] to set upper, lower, digit, space, special
            IF i >= 2 AND pwd[i] == pwd[i-1] AND pwd[i] == pwd[i-2] THEN
                SET repeat3 = TRUE
            END IF
        END FOR

        Append missing category or repetition messages to failures
        FOR EACH word IN prohibited DO
            IF word IN LOWER(pwd) THEN APPEND prohibited message TO failures END IF
        END FOR

        APPEND (pwd, LENGTH(failures) == 0, failures) TO results
    END FOR

    PRINT detailed PASS/FAIL report and totals
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 5 (PDF #29): Password Policy Validation Engine
# Syllabus Concepts: Strings, Loops, Conditionals, Lists, Tuples, Unpacking

count = int(input("Enter number of sample passwords to evaluate: "))
prohibited_words = ("password", "admin", "1234", "qwerty", "welcome")
special_chars = "!@#$%^&*()-_=+[]{}|;:,.<>?/"

results = []

for idx in range(count):
    pwd = input("Enter candidate password: ").strip()
    failures = []

    # Rule 1: Minimum length >= 8 and no spaces
    if len(pwd) < 8:
        failures.append("Length < 8 chars")

    has_upper = False
    has_lower = False
    has_digit = False
    has_special = False
    has_space = False
    has_triple_repeat = False

    for i in range(len(pwd)):
        ch = pwd[i]
        if ch.isupper():
            has_upper = True
        elif ch.islower():
            has_lower = True
        elif ch.isdigit():
            has_digit = True
        elif ch == " ":
            has_space = True
        elif ch in special_chars:
            has_special = True

        # Rule 3: No 3 consecutive identical characters (e.g., 'aaa' or '111')
        if i >= 2 and pwd[i] == pwd[i - 1] and pwd[i] == pwd[i - 2]:
            has_triple_repeat = True

    if has_space:
        failures.append("Contains whitespace")
    if not has_upper:
        failures.append("Missing uppercase letter")
    if not has_lower:
        failures.append("Missing lowercase letter")
    if not has_digit:
        failures.append("Missing numeric digit")
    if not has_special:
        failures.append("Missing special character")
    if has_triple_repeat:
        failures.append("Contains 3+ consecutive repeated chars")

    # Rule 4: Prohibited substring check (case-insensitive)
    lower_pwd = pwd.lower()
    matched_banned = ""
    for banned in prohibited_words:
        if banned in lower_pwd:
            if matched_banned == "":
                matched_banned = banned
            else:
                matched_banned = matched_banned + ", " + banned

    if matched_banned != "":
        failures.append("Contains prohibited substring (" + matched_banned + ")")

    is_valid = len(failures) == 0
    results.append((pwd, is_valid, failures))

print("\n======================================================================")
print("                 PASSWORD POLICY VALIDATION ENGINE                    ")
print("======================================================================")

valid_total = 0
for record in results:
    pwd, is_valid, fail_list = record
    if is_valid:
        valid_total = valid_total + 1
        print("[PASS] '" + pwd + "' -> Meets all security policy rules.")
    else:
        reason_str = ""
        for k in range(len(fail_list)):
            if k > 0:
                reason_str = reason_str + "; "
            reason_str = reason_str + fail_list[k]
        print("[FAIL] '" + pwd + "' -> Failed (" + str(len(fail_list)) + "): " + reason_str)

print("----------------------------------------------------------------------")
print("Summary: Evaluated =", len(results), "| Compliant =", valid_total, "| Non-Compliant =", len(results) - valid_total)
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | Mixed batch with strong password, prohibited substrings, and triple-char repetition | `3<br>Secur3#Key9<br>Admin1234!<br>Ab1!aaaX` | Secur3#Key9 passes; Admin1234! fails on prohibited substrings (admin, 1234); Ab1!aaaX fails on 3+ consecutive repeated chars. | PASS |
| **TC-02** (Boundary / Tie) | Exact 8-character boundary password vs 7-character near-miss | `2<br>Kp9$mN2x<br>Kp9$mN2` | 8-char Kp9$mN2x passes all rules; 7-char Kp9$mN2 fails strictly on Length < 8 chars. | PASS |
| **TC-03** (Edge / Validation) | Weak password triggering five simultaneous rule violations | `1<br>abc def` | Reports all 5 failures: Length < 8, whitespace, missing uppercase, missing digit, and missing special character. | PASS |

---

## 9. Output Screenshots

### TC-01: Mixed batch with strong password, prohibited substrings, and triple-char repetition (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter number of sample passwords to evaluate: 3
Enter candidate password: Secur3#Key9
Enter candidate password: Admin1234!
Enter candidate password: Ab1!aaaX

======================================================================
                 PASSWORD POLICY VALIDATION ENGINE                    
======================================================================
[PASS] 'Secur3#Key9' -> Meets all security policy rules.
[FAIL] 'Admin1234!' -> Failed (1): Contains prohibited substring (admin, 1234)
[FAIL] 'Ab1!aaaX' -> Failed (1): Contains 3+ consecutive repeated chars
----------------------------------------------------------------------
Summary: Evaluated = 3 | Compliant = 1 | Non-Compliant = 2
======================================================================
```
</details>

### TC-02: Exact 8-character boundary password vs 7-character near-miss (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter number of sample passwords to evaluate: 2
Enter candidate password: Kp9$mN2x
Enter candidate password: Kp9$mN2

======================================================================
                 PASSWORD POLICY VALIDATION ENGINE                    
======================================================================
[PASS] 'Kp9$mN2x' -> Meets all security policy rules.
[FAIL] 'Kp9$mN2' -> Failed (1): Length < 8 chars
----------------------------------------------------------------------
Summary: Evaluated = 2 | Compliant = 1 | Non-Compliant = 1
======================================================================
```
</details>

### TC-03: Weak password triggering five simultaneous rule violations (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter number of sample passwords to evaluate: 1
Enter candidate password: abc def

======================================================================
                 PASSWORD POLICY VALIDATION ENGINE                    
======================================================================
[FAIL] 'abc def' -> Failed (5): Length < 8 chars; Contains whitespace; Missing uppercase letter; Missing numeric digit; Missing special character
----------------------------------------------------------------------
Summary: Evaluated = 1 | Compliant = 0 | Non-Compliant = 1
======================================================================
```
</details>

---

## 10. Conclusion

Password Policy Validation Engine demonstrates comprehensive string traversal, sliding-window character comparison, and substring scanning without regular expressions, providing actionable multi-reason security diagnostics.
