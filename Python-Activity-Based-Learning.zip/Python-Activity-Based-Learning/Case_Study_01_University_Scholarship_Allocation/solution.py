# Case Study 1 (PDF #1): University Scholarship Allocation
# Syllabus Concepts: Variables, Data Types, Operators, Conditionals, Loops, Lists, Tuples, Unpacking

n = int(input("Enter number of applicants: "))
quota = int(input("Enter maximum scholarship seats: "))
income_limit = float(input("Enter maximum annual family income limit: "))

applicants = []

for i in range(n):
    raw = input("Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: ").strip()
    parts = raw.split(",")
    roll_no = parts[0].strip()
    name = parts[1].strip()
    m1 = float(parts[2].strip())
    m2 = float(parts[3].strip())
    m3 = float(parts[4].strip())
    attendance = float(parts[5].strip())
    income = float(parts[6].strip())

    # Store applicant record as a tuple
    record = (roll_no, name, (m1, m2, m3), attendance, income)
    applicants.append(record)

eligible = []
rejected = []

for record in applicants:
    # Tuple unpacking
    roll_no, name, marks_tuple, attendance, income = record
    s1, s2, s3 = marks_tuple
    aggregate = (s1 + s2 + s3) / 3.0

    reasons = ""
    if s1 < 60.0 or s2 < 60.0 or s3 < 60.0:
        reasons = reasons + "Subject Min < 60; "
    if aggregate < 75.0:
        reasons = reasons + "Aggregate < 75%; "
    if attendance < 80.0:
        reasons = reasons + "Attendance < 80%; "
    if income > income_limit:
        reasons = reasons + "Income Exceeds Limit; "

    if reasons == "":
        eligible.append((roll_no, name, round(aggregate, 2), attendance, income))
    else:
        rejected.append((roll_no, name, round(aggregate, 2), reasons[:-2]))

# Rank eligible students using nested loop comparison and predefined tie-breaking rules:
# Rule 1: Higher Aggregate %
# Rule 2: Higher Attendance %
# Rule 3: Lower Family Income
# Rule 4: Lexicographically smaller Roll Number
el_count = len(eligible)
for i in range(el_count):
    for j in range(0, el_count - i - 1):
        r1, n1, agg1, att1, inc1 = eligible[j]
        r2, n2, agg2, att2, inc2 = eligible[j + 1]

        swap_needed = False
        if agg2 > agg1:
            swap_needed = True
        elif agg2 == agg1:
            if att2 > att1:
                swap_needed = True
            elif att2 == att1:
                if inc2 < inc1:
                    swap_needed = True
                elif inc2 == inc1 and r2 < r1:
                    swap_needed = True

        if swap_needed:
            eligible[j], eligible[j + 1] = eligible[j + 1], eligible[j]

print("\n======================================================================")
print("             UNIVERSITY SCHOLARSHIP ALLOCATION REPORT                 ")
print("======================================================================")
print("Total Applicants :", n, "| Eligible :", len(eligible), "| Quota :", quota)
print("----------------------------------------------------------------------")
print("RANKED ELIGIBLE APPLICANTS:")

if len(eligible) == 0:
    print("No applicants met all scholarship criteria.")
else:
    rank = 1
    for item in eligible:
        roll_no, name, agg, att, inc = item
        if rank <= quota:
            status = "AWARDED"
        else:
            status = "WAITLISTED"
        print("Rank", rank, "|", roll_no, "|", name, "| Agg:", format(agg, ".2f") + "%", "| Att:", format(att, ".1f") + "%", "| Inc:", format(inc, ".0f"), "|", status)
        rank = rank + 1

print("----------------------------------------------------------------------")
print("NON-ELIGIBLE APPLICANTS:")
if len(rejected) == 0:
    print("None")
else:
    for item in rejected:
        roll_no, name, agg, reason_text = item
        print(roll_no, "|", name, "| Agg:", format(agg, ".2f") + "%", "| Reason:", reason_text)
print("======================================================================")
