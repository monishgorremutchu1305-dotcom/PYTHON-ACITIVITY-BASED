# Case Study 01 (PDF #1): University Scholarship Allocation System


**Assigned Syllabus Concepts Used:** Tuples & Unpacking, Nested Lists, Conditional Statements, Nested Loop Ranking

---

## 1. Problem Statement

> **PDF Prompt (#1):** 1. University Scholarship Allocation: Design a system that evaluates applicants using aggregate marks, subject-wise minimum scores, attendance, and income criteria, ranks eligible students, and resolves ties using predefined rules.

Universities receive numerous merit-cum-means scholarship applications every semester and must allocate a fixed quota of scholarships fairly and transparently. Each applicant record consists of Roll Number, Student Name, marks across three core subjects, attendance percentage, and annual family income. An applicant is eligible only if every individual subject score is at least 60, aggregate marks are at least 75%, attendance is at least 80%, and family income does not exceed the prescribed ceiling. Eligible candidates must be ranked in descending order of aggregate marks, resolving ties deterministically by higher attendance, lower family income, and finally lexicographical Roll Number order.

---

## 2. Objectives

1. Represent heterogeneous student application records using immutable tuples and nested subject-mark tuples.
2. Validate multi-condition scholarship eligibility (subject minimums, aggregate threshold, attendance floor, and income ceiling) while logging all unmet conditions.
3. Implement deterministic in-place ranking using nested loops and multi-level tie-breaking rules without relying on external libraries or lambda functions.
4. Classify ranked eligible applicants into AWARDED (within quota) and WAITLISTED (beyond quota) tiers and generate a formatted audit report.

---

## 3. Assumptions

- Marks in each of the 3 evaluated core subjects range from 0.0 to 100.0, with a mandatory minimum of 60.0 per subject.
- Minimum aggregate score for scholarship eligibility is 75.00% and minimum required attendance is 80.0%.
- Annual family income must be less than or equal to the user-supplied income ceiling (in INR).
- Tie-breaking precedence strictly follows: (1) Higher Aggregate %, (2) Higher Attendance %, (3) Lower Annual Income, and (4) Ascending Roll Number.
- Only assigned syllabus constructs (variables, operators, conditionals, loops, strings, lists, tuples, and unpacking) are used.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read total number of applicants N, scholarship seat quota Q, and maximum family income limit I_max.
- **Step 3:** Initialize empty lists `applicants`, `eligible`, and `rejected`.
- **Step 4:** Repeat N times: read comma-separated RollNo, Name, Sub1, Sub2, Sub3, Attendance, and Income; store as nested tuple `(roll_no, name, (m1, m2, m3), attendance, income)` in `applicants`.
- **Step 5:** For each tuple in `applicants`, unpack fields and compute `aggregate = (s1 + s2 + s3) / 3.0`.
- **Step 6:** Check all four eligibility rules (`s1,s2,s3 >= 60`, `aggregate >= 75`, `attendance >= 80`, `income <= I_max`). If all hold, append to `eligible`; otherwise concatenate all failure reasons and append to `rejected`.
- **Step 7:** Sort `eligible` using nested Bubble Sort loops: compare adjacent tuples `(j)` and `(j+1)` by higher aggregate, then higher attendance, then lower income, then smaller `roll_no`, swapping when needed.
- **Step 8:** Traverse sorted `eligible` list with `rank` starting from 1; mark status as `AWARDED` if `rank <= Q`, else `WAITLISTED`, and display each ranked record.
- **Step 9:** Traverse `rejected` list and print each non-eligible student along with exact rejection reasons.
- **Step 10:** Stop the program.

---

## 5. Flowchart

![Flowchart - University Scholarship Allocation System](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT n, quota, income_limit
    SET applicants = [], eligible = [], rejected = []

    FOR i = 1 TO n DO
        INPUT roll_no, name, m1, m2, m3, attendance, income
        APPEND (roll_no, name, (m1, m2, m3), attendance, income) TO applicants
    END FOR

    FOR EACH record IN applicants DO
        UNPACK (roll_no, name, (s1, s2, s3), attendance, income) FROM record
        SET aggregate = (s1 + s2 + s3) / 3.0
        SET reasons = ""

        IF s1 < 60 OR s2 < 60 OR s3 < 60 THEN CONCAT "Subject Min < 60; " TO reasons END IF
        IF aggregate < 75 THEN CONCAT "Aggregate < 75%; " TO reasons END IF
        IF attendance < 80 THEN CONCAT "Attendance < 80%; " TO reasons END IF
        IF income > income_limit THEN CONCAT "Income Exceeds Limit; " TO reasons END IF

        IF reasons == "" THEN
            APPEND (roll_no, name, ROUND(aggregate, 2), attendance, income) TO eligible
        ELSE
            APPEND (roll_no, name, ROUND(aggregate, 2), reasons) TO rejected
        END IF
    END FOR

    FOR i = 0 TO LENGTH(eligible) - 1 DO
        FOR j = 0 TO LENGTH(eligible) - i - 2 DO
            UNPACK r1, n1, agg1, att1, inc1 FROM eligible[j]
            UNPACK r2, n2, agg2, att2, inc2 FROM eligible[j + 1]
            IF (agg2 > agg1) OR
               (agg2 == agg1 AND att2 > att1) OR
               (agg2 == agg1 AND att2 == att1 AND inc2 < inc1) OR
               (agg2 == agg1 AND att2 == att1 AND inc2 == inc1 AND r2 < r1) THEN
                SWAP eligible[j] AND eligible[j + 1]
            END IF
        END FOR
    END FOR

    FOR rank = 1 TO LENGTH(eligible) DO
        IF rank <= quota THEN status = "AWARDED" ELSE status = "WAITLISTED" END IF
        PRINT rank, eligible[rank - 1], status
    END FOR
    PRINT rejected
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 1 (PDF #1): University Scholarship Allocation
# Syllabus Concepts: Variables, Data Types, Operators, Conditionals, Loops, Lists, Tuples, Unpacking

n = int(input("Enter number of applicants: "))
quota = int(input("Enter maximum scholarship seats: "))
income_limit = float(input("Enter maximum annual family income limit: "))

applicants = []

for i in range(n):
    raw = input("Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: ").strip()
    parts = raw.split(",")
    roll_no = parts[0].strip()
    name = parts[1].strip()
    m1 = float(parts[2].strip())
    m2 = float(parts[3].strip())
    m3 = float(parts[4].strip())
    attendance = float(parts[5].strip())
    income = float(parts[6].strip())

    # Store applicant record as a tuple
    record = (roll_no, name, (m1, m2, m3), attendance, income)
    applicants.append(record)

eligible = []
rejected = []

for record in applicants:
    # Tuple unpacking
    roll_no, name, marks_tuple, attendance, income = record
    s1, s2, s3 = marks_tuple
    aggregate = (s1 + s2 + s3) / 3.0

    reasons = ""
    if s1 < 60.0 or s2 < 60.0 or s3 < 60.0:
        reasons = reasons + "Subject Min < 60; "
    if aggregate < 75.0:
        reasons = reasons + "Aggregate < 75%; "
    if attendance < 80.0:
        reasons = reasons + "Attendance < 80%; "
    if income > income_limit:
        reasons = reasons + "Income Exceeds Limit; "

    if reasons == "":
        eligible.append((roll_no, name, round(aggregate, 2), attendance, income))
    else:
        rejected.append((roll_no, name, round(aggregate, 2), reasons[:-2]))

# Rank eligible students using nested loop comparison and predefined tie-breaking rules:
# Rule 1: Higher Aggregate %
# Rule 2: Higher Attendance %
# Rule 3: Lower Family Income
# Rule 4: Lexicographically smaller Roll Number
el_count = len(eligible)
for i in range(el_count):
    for j in range(0, el_count - i - 1):
        r1, n1, agg1, att1, inc1 = eligible[j]
        r2, n2, agg2, att2, inc2 = eligible[j + 1]

        swap_needed = False
        if agg2 > agg1:
            swap_needed = True
        elif agg2 == agg1:
            if att2 > att1:
                swap_needed = True
            elif att2 == att1:
                if inc2 < inc1:
                    swap_needed = True
                elif inc2 == inc1 and r2 < r1:
                    swap_needed = True

        if swap_needed:
            eligible[j], eligible[j + 1] = eligible[j + 1], eligible[j]

print("\n======================================================================")
print("             UNIVERSITY SCHOLARSHIP ALLOCATION REPORT                 ")
print("======================================================================")
print("Total Applicants :", n, "| Eligible :", len(eligible), "| Quota :", quota)
print("----------------------------------------------------------------------")
print("RANKED ELIGIBLE APPLICANTS:")

if len(eligible) == 0:
    print("No applicants met all scholarship criteria.")
else:
    rank = 1
    for item in eligible:
        roll_no, name, agg, att, inc = item
        if rank <= quota:
            status = "AWARDED"
        else:
            status = "WAITLISTED"
        print("Rank", rank, "|", roll_no, "|", name, "| Agg:", format(agg, ".2f") + "%", "| Att:", format(att, ".1f") + "%", "| Inc:", format(inc, ".0f"), "|", status)
        rank = rank + 1

print("----------------------------------------------------------------------")
print("NON-ELIGIBLE APPLICANTS:")
if len(rejected) == 0:
    print("None")
else:
    for item in rejected:
        roll_no, name, agg, reason_text = item
        print(roll_no, "|", name, "| Agg:", format(agg, ".2f") + "%", "| Reason:", reason_text)
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | Multi-level tie-breaking on aggregate & attendance with quota cutoff | `4<br>2<br>250000<br>CS101,Aarav Sharma,88,92,85,89,180000<br>CS102,Diya Nair,90,85,90,91,210000<br>CS103,Rohan Verma,88,92,85,89,165000<br>CS104,Sneha Iyer,95,58,92,94,150000` | CS102 ranked #1 (higher attendance 91% on 88.33% tie), CS103 ranked #2 AWARDED (lower income 165000 vs CS101), CS101 WAITLISTED, CS104 rejected for Subject Min < 60. | PASS |
| **TC-02** (Boundary / Tie) | Exact tie across aggregate, attendance, and income resolved by RollNo | `2<br>1<br>300000<br>CS205,Kiran Rao,84,84,84,90,150000<br>CS201,Meera Sen,82,86,84,90,150000` | Both have 84.00% aggregate, 90.0% attendance, and 150000 income; CS201 precedes CS205 lexicographically and receives AWARDED. | PASS |
| **TC-03** (Edge / Validation) | Zero eligible candidates with compound rejection reasons | `2<br>2<br>200000<br>CS301,Dev Patel,70,72,68,76,180000<br>CS302,Nisha Roy,85,88,90,85,260000` | Prints empty-eligibility message and lists multiple simultaneous unmet conditions for CS301 and income violation for CS302. | PASS |

---

## 9. Output Screenshots

### TC-01: Multi-level tie-breaking on aggregate & attendance with quota cutoff (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter number of applicants: 4
Enter maximum scholarship seats: 2
Enter maximum annual family income limit: 250000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS101,Aarav Sharma,88,92,85,89,180000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS102,Diya Nair,90,85,90,91,210000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS103,Rohan Verma,88,92,85,89,165000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS104,Sneha Iyer,95,58,92,94,150000

======================================================================
             UNIVERSITY SCHOLARSHIP ALLOCATION REPORT                 
======================================================================
Total Applicants : 4 | Eligible : 3 | Quota : 2
----------------------------------------------------------------------
RANKED ELIGIBLE APPLICANTS:
Rank 1 | CS102 | Diya Nair | Agg: 88.33% | Att: 91.0% | Inc: 210000 | AWARDED
Rank 2 | CS103 | Rohan Verma | Agg: 88.33% | Att: 89.0% | Inc: 165000 | AWARDED
Rank 3 | CS101 | Aarav Sharma | Agg: 88.33% | Att: 89.0% | Inc: 180000 | WAITLISTED
----------------------------------------------------------------------
NON-ELIGIBLE APPLICANTS:
CS104 | Sneha Iyer | Agg: 81.67% | Reason: Subject Min < 60
======================================================================
```
</details>

### TC-02: Exact tie across aggregate, attendance, and income resolved by RollNo (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter number of applicants: 2
Enter maximum scholarship seats: 1
Enter maximum annual family income limit: 300000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS205,Kiran Rao,84,84,84,90,150000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS201,Meera Sen,82,86,84,90,150000

======================================================================
             UNIVERSITY SCHOLARSHIP ALLOCATION REPORT                 
======================================================================
Total Applicants : 2 | Eligible : 2 | Quota : 1
----------------------------------------------------------------------
RANKED ELIGIBLE APPLICANTS:
Rank 1 | CS201 | Meera Sen | Agg: 84.00% | Att: 90.0% | Inc: 150000 | AWARDED
Rank 2 | CS205 | Kiran Rao | Agg: 84.00% | Att: 90.0% | Inc: 150000 | WAITLISTED
----------------------------------------------------------------------
NON-ELIGIBLE APPLICANTS:
None
======================================================================
```
</details>

### TC-03: Zero eligible candidates with compound rejection reasons (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter number of applicants: 2
Enter maximum scholarship seats: 2
Enter maximum annual family income limit: 200000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS301,Dev Patel,70,72,68,76,180000
Enter RollNo,Name,Sub1,Sub2,Sub3,Attendance,Income: CS302,Nisha Roy,85,88,90,85,260000

======================================================================
             UNIVERSITY SCHOLARSHIP ALLOCATION REPORT                 
======================================================================
Total Applicants : 2 | Eligible : 0 | Quota : 2
----------------------------------------------------------------------
RANKED ELIGIBLE APPLICANTS:
No applicants met all scholarship criteria.
----------------------------------------------------------------------
NON-ELIGIBLE APPLICANTS:
CS301 | Dev Patel | Agg: 70.00% | Reason: Aggregate < 75%; Attendance < 80%
CS302 | Nisha Roy | Agg: 87.67% | Reason: Income Exceeds Limit
======================================================================
```
</details>

---

## 10. Conclusion

The University Scholarship Allocation system successfully models multi-criteria academic screening using nested tuples, tuple unpacking, conditional validation, and nested-loop sorting. Every tie-breaking tier (aggregate, attendance, family income, and roll number) executes deterministically without external sorting keys, ensuring fair and transparent quota allocation.
