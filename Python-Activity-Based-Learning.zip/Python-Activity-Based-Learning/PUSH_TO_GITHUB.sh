#!/usr/bin/env bash
# Quick Git Upload Script for Python-Activity-Based-Learning
# Prerequisite: Create a new empty repository named "Python-Activity-Based-Learning" on https://github.com/new

set -e

git init
git add .
git commit -m "Submit 10 Python Activity-Based Learning case studies with all mandatory deliverables"
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/Python-Activity-Based-Learning.git
git push -u origin main

echo "Successfully pushed to https://github.com/YOUR_GITHUB_USERNAME/Python-Activity-Based-Learning"
