# Case Study 9 (PDF #48): Tuple-Based Employee Shift Conflict Detection
# Syllabus Concepts: Tuples, Tuple Operations, Unpacking, Nested Loops, Conditionals, Lists

num_shifts = int(input("Enter number of shift assignments: "))
valid_shifts = []
invalid_shifts = []

for i in range(num_shifts):
    raw = input("Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: ").strip()
    parts = raw.split(",")
    shift_id = parts[0].strip()
    emp_id = parts[1].strip()
    emp_name = parts[2].strip()
    day = parts[3].strip().upper()
    start_hr = float(parts[4].strip())
    end_hr = float(parts[5].strip())

    shift_tuple = (shift_id, emp_id, emp_name, day, start_hr, end_hr)

    if start_hr < 0 or end_hr > 24 or start_hr >= end_hr:
        invalid_shifts.append(shift_tuple)
    else:
        valid_shifts.append(shift_tuple)

conflicts = []
conflicted_employees = []

# Compare pairs of valid shifts using nested loops and tuple unpacking
v_len = len(valid_shifts)
for i in range(v_len):
    sid1, eid1, ename1, day1, s1, e1 = valid_shifts[i]
    for j in range(i + 1, v_len):
        sid2, eid2, ename2, day2, s2, e2 = valid_shifts[j]

        # Same employee on the same day with overlapping interval: max(s1, s2) < min(e1, e2)
        if eid1 == eid2 and day1 == day2:
            overlap_start = s1
            if s2 > overlap_start:
                overlap_start = s2
            overlap_end = e1
            if e2 < overlap_end:
                overlap_end = e2

            if overlap_start < overlap_end:
                conflicts.append((eid1, ename1, day1, sid1, s1, e1, sid2, s2, e2, overlap_end - overlap_start))
                emp_tag = eid1 + " (" + ename1 + ")"
                if emp_tag not in conflicted_employees:
                    conflicted_employees.append(emp_tag)

print("\n======================================================================")
print("          TUPLE-BASED EMPLOYEE SHIFT CONFLICT DETECTION               ")
print("======================================================================")
print("Total Records:", num_shifts, "| Valid Shifts:", len(valid_shifts), "| Invalid Time Ranges:", len(invalid_shifts))

if len(invalid_shifts) > 0:
    print("----------------------------------------------------------------------")
    print("INVALID SHIFT INTERVALS REJECTED:")
    for bad in invalid_shifts:
        sid, eid, ename, day, sh, eh = bad
        print(" ->", sid, "|", eid, ename, "|", day, "|", format(sh, ".1f"), "to", format(eh, ".1f"), "(Invalid Hours)")

print("----------------------------------------------------------------------")
print("OVERLAPPING SHIFT CONFLICTS DETECTED:")
if len(conflicts) == 0:
    print("No overlapping employee shift assignments detected.")
else:
    for c_rec in conflicts:
        eid, ename, day, sid1, s1, e1, sid2, s2, e2, ov_hrs = c_rec
        print("Conflict:", eid, ename, "on", day, "|", sid1 + "(" + format(s1, ".1f") + "-" + format(e1, ".1f") + ") overlaps", sid2 + "(" + format(s2, ".1f") + "-" + format(e2, ".1f") + ") by", format(ov_hrs, ".1f"), "hrs")

print("----------------------------------------------------------------------")
if len(conflicted_employees) == 0:
    print("Employees With Conflicting Schedules: None")
else:
    emp_summary = ""
    for k in range(len(conflicted_employees)):
        if k > 0:
            emp_summary = emp_summary + ", "
        emp_summary = emp_summary + conflicted_employees[k]
    print("Employees With Conflicting Schedules:", emp_summary)
print("======================================================================")
