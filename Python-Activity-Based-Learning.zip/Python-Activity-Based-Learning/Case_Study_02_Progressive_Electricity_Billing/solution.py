# Case Study 2 (PDF #2): Progressive Electricity Billing
# Syllabus Concepts: Variables, Operators, Multi-Slab Conditionals, Loops, Lists, Tuples, Unpacking

household_id = input("Enter Household Consumer ID: ").strip()
num_months = int(input("Enter number of months to analyse: "))

monthly_records = []
fixed_charge = 75.0

for i in range(num_months):
    raw = input("Enter MonthName,UnitsConsumed: ").strip()
    parts = raw.split(",")
    month_name = parts[0].strip()
    units = float(parts[1].strip())

    # Validate non-negative consumption
    if units < 0:
        units = 0.0

    # Progressive Consumption Slabs:
    # 0 - 100 units   : Rs. 3.00 / unit
    # 101 - 200 units : Rs. 5.00 / unit
    # 201 - 400 units : Rs. 7.00 / unit
    # Above 400 units : Rs. 9.00 / unit
    if units <= 100:
        energy_charge = units * 3.0
    elif units <= 200:
        energy_charge = (100 * 3.0) + ((units - 100) * 5.0)
    elif units <= 400:
        energy_charge = (100 * 3.0) + (100 * 5.0) + ((units - 200) * 7.0)
    else:
        energy_charge = (100 * 3.0) + (100 * 5.0) + (200 * 7.0) + ((units - 400) * 9.0)

    # Low-consumption rebate and high-load surcharge rules
    rebate = 0.0
    surcharge = 0.0
    if units <= 50:
        rebate = 25.0
    elif units > 350:
        surcharge = 0.10 * energy_charge

    net_bill = energy_charge + fixed_charge + surcharge - rebate
    if net_bill < 0:
        net_bill = 0.0

    monthly_records.append((month_name, units, energy_charge, surcharge, rebate, net_bill))

print("\n======================================================================")
print("         PROGRESSIVE ELECTRICITY BILLING & SPIKE ANALYSIS             ")
print("======================================================================")
print("Consumer ID:", household_id, "| Fixed Charge: Rs.", format(fixed_charge, ".2f"))
print("----------------------------------------------------------------------")

total_units = 0.0
total_billed = 0.0
unusual_spikes = []

for idx in range(len(monthly_records)):
    m_name, u_val, e_chg, sur, reb, net = monthly_records[idx]
    total_units = total_units + u_val
    total_billed = total_billed + net

    trend_note = "Baseline"
    if idx > 0:
        prev_month, prev_units, prev_e, prev_s, prev_r, prev_bill = monthly_records[idx - 1]
        if prev_bill > 0:
            pct_change = ((net - prev_bill) / prev_bill) * 100.0
        else:
            pct_change = 0.0

        if pct_change > 25.0:
            trend_note = "UNUSUAL INCREASE (+" + format(pct_change, ".1f") + "%)"
            unusual_spikes.append((prev_month, m_name, pct_change, net - prev_bill))
        elif pct_change >= 0:
            trend_note = "Normal (+" + format(pct_change, ".1f") + "%)"
        else:
            trend_note = "Decrease (" + format(pct_change, ".1f") + "%)"

    print(m_name, "| Units:", format(u_val, ".1f"), "| Energy:", format(e_chg, ".2f"), "| Sur:", format(sur, ".2f"), "| Reb:", format(reb, ".2f"), "| Net: Rs.", format(net, ".2f"), "|", trend_note)

avg_bill = 0.0
if num_months > 0:
    avg_bill = total_billed / num_months

print("----------------------------------------------------------------------")
print("Total Units:", format(total_units, ".1f"), "| Total Billed: Rs.", format(total_billed, ".2f"), "| Monthly Avg: Rs.", format(avg_bill, ".2f"))
if len(unusual_spikes) == 0:
    print("Spike Alert: No unusual bill increases (>25%) detected.")
else:
    for spike in unusual_spikes:
        from_m, to_m, pct, diff = spike
        print("Spike Alert:", to_m, "increased by", format(pct, ".1f") + "% (+Rs.", format(diff, ".2f") + ") compared to", from_m)
print("======================================================================")
