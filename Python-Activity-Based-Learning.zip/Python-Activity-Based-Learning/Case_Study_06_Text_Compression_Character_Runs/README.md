# Case Study 06 (PDF #35): Text Compression Using Character Runs (RLE)


**Assigned Syllabus Concepts Used:** String Traversal, Run-Length Grouping, Length Comparison, Tuples & Unpacking

---

## 1. Problem Statement

> **PDF Prompt (#35):** 35. Text Compression Using Character Runs: Encode a string by grouping consecutive repeated characters and compare original and encoded lengths, including cases where encoding is not beneficial.

Run-Length Encoding (RLE) is a lossless data compression technique widely used in monochrome scanlines, telemetry streams, and icon bitmaps. Consecutive identical characters are collapsed into `<char><count>` tokens (for example, `AAAABBB` becomes `A4B3`). However, on high-entropy strings without adjacent repeats (such as `ABCDEF` -> `A1B1C1D1E1F1`), RLE inflates string size. The program must encode input strings, compare original and encoded lengths, compute percentage savings, and intelligently retain the original string whenever RLE is not beneficial.

---

## 2. Objectives

1. Group consecutive identical characters in a single linear pass using index-controlled `for` loops.
2. Construct run-length encoded strings of the form `<character><run_length>` without using external compression modules.
3. Compare original vs. encoded string lengths and calculate exact character savings and compression percentage.
4. Detect non-beneficial expansions (`encoded_length >= original_length`) and select the shorter representation for storage.

---

## 3. Assumptions

- Character comparison is case-sensitive (`A` and `a` are treated as distinct runs).
- An empty string `""` encodes to `""` with 0% savings and is marked non-beneficial.
- Compression is strictly beneficial only when `len(encoded) < len(original)`.
- When encoding increases or equals the original length, the system retains the original string as the stored form.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read number of test strings `num_strings` and initialize `records = []`.
- **Step 3:** Repeat `num_strings` times: read `original` string and compute `orig_len = len(original)`.
- **Step 4:** If `orig_len == 0`, set `encoded = ""`; otherwise initialize `run_char = original[0]`, `run_count = 1`, and `encoded = ""`.
- **Step 5:** Loop `i` from `1` to `orig_len - 1`: if `original[i] == run_char`, increment `run_count`; else append `run_char + str(run_count)` to `encoded` and reset `run_char = original[i]`, `run_count = 1`.
- **Step 6:** After the loop ends, append the final `run_char + str(run_count)` to `encoded`.
- **Step 7:** Compute `enc_len = len(encoded)`, `saved_chars = orig_len - enc_len`, `ratio_pct`, and `beneficial = (enc_len < orig_len)`.
- **Step 8:** Store tuple `(original, encoded, orig_len, enc_len, saved_chars, ratio_pct, beneficial)` in `records`.
- **Step 9:** Unpack each record, print original vs. encoded lengths, beneficial verdict, optimal stored string, and summary count.
- **Step 10:** Stop the program.

---

## 5. Flowchart

![Flowchart - Text Compression Using Character Runs (RLE)](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT num_strings
    SET records = []

    FOR s_idx = 1 TO num_strings DO
        INPUT original
        SET orig_len = LENGTH(original)

        IF orig_len == 0 THEN
            SET encoded = ""
        ELSE
            SET encoded = "", run_char = original[0], run_count = 1
            FOR i = 1 TO orig_len - 1 DO
                IF original[i] == run_char THEN
                    SET run_count = run_count + 1
                ELSE
                    SET encoded = encoded + run_char + STR(run_count)
                    SET run_char = original[i], run_count = 1
                END IF
            END FOR
            SET encoded = encoded + run_char + STR(run_count)
        END IF

        SET enc_len = LENGTH(encoded)
        SET saved = orig_len - enc_len
        SET beneficial = (orig_len > 0) AND (enc_len < orig_len)
        APPEND (original, encoded, orig_len, enc_len, saved, beneficial) TO records
    END FOR

    FOR EACH rec IN records DO
        IF rec.beneficial THEN chosen = rec.encoded ELSE chosen = rec.original END IF
        PRINT rec.original, rec.encoded, rec.saved, chosen
    END FOR
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 6 (PDF #35): Text Compression Using Character Runs
# Syllabus Concepts: Strings, Loops, Conditionals, Operators, Lists, Tuples, Unpacking

num_strings = int(input("Enter number of strings to process: "))
records = []

for s_idx in range(num_strings):
    original = input("Enter input string: ")
    orig_len = len(original)

    if orig_len == 0:
        encoded = ""
    else:
        encoded = ""
        run_char = original[0]
        run_count = 1

        for i in range(1, orig_len):
            if original[i] == run_char:
                run_count = run_count + 1
            else:
                encoded = encoded + run_char + str(run_count)
                run_char = original[i]
                run_count = 1

        # Append final run
        encoded = encoded + run_char + str(run_count)

    enc_len = len(encoded)
    saved_chars = orig_len - enc_len

    if orig_len == 0:
        ratio_pct = 0.0
        beneficial = False
    else:
        ratio_pct = (saved_chars / orig_len) * 100.0
        beneficial = enc_len < orig_len

    records.append((original, encoded, orig_len, enc_len, saved_chars, ratio_pct, beneficial))

print("\n======================================================================")
print("            TEXT COMPRESSION USING CHARACTER RUNS (RLE)               ")
print("======================================================================")

beneficial_count = 0
for rec in records:
    orig_s, enc_s, o_len, e_len, saved, pct, is_good = rec
    if o_len == 0:
        verdict = "EMPTY INPUT (No Compression)"
        chosen_output = orig_s
    elif is_good:
        verdict = "BENEFICIAL (Saved " + str(saved) + " chars, " + format(pct, ".1f") + "%)"
        chosen_output = enc_s
        beneficial_count = beneficial_count + 1
    else:
        verdict = "NOT BENEFICIAL (Retain Original)"
        chosen_output = orig_s

    print("Original :", "'" + orig_s + "' (Len:", str(o_len) + ") -> Encoded :", "'" + enc_s + "' (Len:", str(e_len) + ")")
    print("Decision :", verdict, "| Stored Form:", "'" + chosen_output + "'")
    print("----------------------------------------------------------------------")

print("Total Strings Processed:", len(records), "| Beneficial Compressions:", beneficial_count)
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | Mixed batch comparing beneficial runs, non-repeating expansion, and long scanline | `3<br>AAAABBBCCDAA<br>ABCDEF<br>WWWWWWWWWWWWBWWWWWWWWWWWWBBB` | Compresses #1 (16.7% saved) and #3 (64.3% saved); detects negative gain on ABCDEF (Len 6 -> 12) and retains original. | PASS |
| **TC-02** (Boundary / Tie) | Equal-length boundary where encoded length equals original length (AABB -> A2B2) | `2<br>AABB<br>AAABBB` | AABB (Len 4 -> Len 4) yields 0 chars saved and is marked NOT BENEFICIAL; AAABBB (Len 6 -> Len 4) saves 33.3%. | PASS |
| **TC-03** (Edge / Validation) | Case-sensitivity check (aaAA) and single-character input | `2<br>aaAA<br>Z` | Separates lowercase a2 and uppercase A2 (Len 4 -> 4, retain original); single char Z -> Z1 (not beneficial). | PASS |

---

## 9. Output Screenshots

### TC-01: Mixed batch comparing beneficial runs, non-repeating expansion, and long scanline (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter number of strings to process: 3
Enter input string: AAAABBBCCDAA
Enter input string: ABCDEF
Enter input string: WWWWWWWWWWWWBWWWWWWWWWWWWBBB

======================================================================
            TEXT COMPRESSION USING CHARACTER RUNS (RLE)               
======================================================================
Original : 'AAAABBBCCDAA' (Len: 12) -> Encoded : 'A4B3C2D1A2' (Len: 10)
Decision : BENEFICIAL (Saved 2 chars, 16.7%) | Stored Form: 'A4B3C2D1A2'
----------------------------------------------------------------------
Original : 'ABCDEF' (Len: 6) -> Encoded : 'A1B1C1D1E1F1' (Len: 12)
Decision : NOT BENEFICIAL (Retain Original) | Stored Form: 'ABCDEF'
----------------------------------------------------------------------
Original : 'WWWWWWWWWWWWBWWWWWWWWWWWWBBB' (Len: 28) -> Encoded : 'W12B1W12B3' (Len: 10)
Decision : BENEFICIAL (Saved 18 chars, 64.3%) | Stored Form: 'W12B1W12B3'
----------------------------------------------------------------------
Total Strings Processed: 3 | Beneficial Compressions: 2
======================================================================
```
</details>

### TC-02: Equal-length boundary where encoded length equals original length (AABB -> A2B2) (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter number of strings to process: 2
Enter input string: AABB
Enter input string: AAABBB

======================================================================
            TEXT COMPRESSION USING CHARACTER RUNS (RLE)               
======================================================================
Original : 'AABB' (Len: 4) -> Encoded : 'A2B2' (Len: 4)
Decision : NOT BENEFICIAL (Retain Original) | Stored Form: 'AABB'
----------------------------------------------------------------------
Original : 'AAABBB' (Len: 6) -> Encoded : 'A3B3' (Len: 4)
Decision : BENEFICIAL (Saved 2 chars, 33.3%) | Stored Form: 'A3B3'
----------------------------------------------------------------------
Total Strings Processed: 2 | Beneficial Compressions: 1
======================================================================
```
</details>

### TC-03: Case-sensitivity check (aaAA) and single-character input (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter number of strings to process: 2
Enter input string: aaAA
Enter input string: Z

======================================================================
            TEXT COMPRESSION USING CHARACTER RUNS (RLE)               
======================================================================
Original : 'aaAA' (Len: 4) -> Encoded : 'a2A2' (Len: 4)
Decision : NOT BENEFICIAL (Retain Original) | Stored Form: 'aaAA'
----------------------------------------------------------------------
Original : 'Z' (Len: 1) -> Encoded : 'Z1' (Len: 2)
Decision : NOT BENEFICIAL (Retain Original) | Stored Form: 'Z'
----------------------------------------------------------------------
Total Strings Processed: 2 | Beneficial Compressions: 0
======================================================================
```
</details>

---

## 10. Conclusion

Text Compression Using Character Runs demonstrates linear-time `O(N)` string scanning, accumulator state management, and practical space-efficiency trade-off evaluation where expansion on short runs is prevented automatically.
