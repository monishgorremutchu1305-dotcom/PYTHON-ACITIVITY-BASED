# Case Study 6 (PDF #35): Text Compression Using Character Runs
# Syllabus Concepts: Strings, Loops, Conditionals, Operators, Lists, Tuples, Unpacking

num_strings = int(input("Enter number of strings to process: "))
records = []

for s_idx in range(num_strings):
    original = input("Enter input string: ")
    orig_len = len(original)

    if orig_len == 0:
        encoded = ""
    else:
        encoded = ""
        run_char = original[0]
        run_count = 1

        for i in range(1, orig_len):
            if original[i] == run_char:
                run_count = run_count + 1
            else:
                encoded = encoded + run_char + str(run_count)
                run_char = original[i]
                run_count = 1

        # Append final run
        encoded = encoded + run_char + str(run_count)

    enc_len = len(encoded)
    saved_chars = orig_len - enc_len

    if orig_len == 0:
        ratio_pct = 0.0
        beneficial = False
    else:
        ratio_pct = (saved_chars / orig_len) * 100.0
        beneficial = enc_len < orig_len

    records.append((original, encoded, orig_len, enc_len, saved_chars, ratio_pct, beneficial))

print("\n======================================================================")
print("            TEXT COMPRESSION USING CHARACTER RUNS (RLE)               ")
print("======================================================================")

beneficial_count = 0
for rec in records:
    orig_s, enc_s, o_len, e_len, saved, pct, is_good = rec
    if o_len == 0:
        verdict = "EMPTY INPUT (No Compression)"
        chosen_output = orig_s
    elif is_good:
        verdict = "BENEFICIAL (Saved " + str(saved) + " chars, " + format(pct, ".1f") + "%)"
        chosen_output = enc_s
        beneficial_count = beneficial_count + 1
    else:
        verdict = "NOT BENEFICIAL (Retain Original)"
        chosen_output = orig_s

    print("Original :", "'" + orig_s + "' (Len:", str(o_len) + ") -> Encoded :", "'" + enc_s + "' (Len:", str(e_len) + ")")
    print("Decision :", verdict, "| Stored Form:", "'" + chosen_output + "'")
    print("----------------------------------------------------------------------")

print("Total Strings Processed:", len(records), "| Beneficial Compressions:", beneficial_count)
print("======================================================================")
