# Case Study 10 (PDF #49): Tuple-Based Product Catalogue Audit


**Assigned Syllabus Concepts Used:** Tuples & Unpacking, String Format Checks, Inventory Valuation, Replenishment Filtering

---

## 1. Problem Statement

> **PDF Prompt (#49):** 49. Tuple-Based Product Catalogue Audit: Store product identifiers, prices, and stock quantities in tuples; detect invalid records, calculate inventory values, and identify items requiring replenishment.

Retail and warehouse ERP imports often contain corrupted product rows such as malformed SKU identifiers, duplicate product IDs, zero/negative unit prices, or negative stock counts. Storing each product record as a 4-tuple `(prod_id, prod_name, price, qty)`, this audit program isolates invalid records with exact diagnostic causes, calculates item-wise and aggregate inventory valuation across valid SKUs, and flags products below the reorder threshold along with minimum order quantities needed.

---

## 2. Objectives

1. Represent product catalogue entries as 4-tuples `(ProductID, ProductName, UnitPrice, StockQty)` and unpack them for auditing.
2. Validate SKU structure (`P` followed by digits), uniqueness across `seen_ids`, non-empty product names, positive prices, and non-negative stock.
3. Calculate per-SKU valuation (`price * qty`) and cumulative warehouse inventory value across validated tuples only.
4. Identify low-stock items (`qty < reorder_threshold`) and compute exact replenishment shortfalls (`threshold - qty`).

---

## 3. Assumptions

- Valid Product IDs begin with uppercase `"P"` followed exclusively by one or more digits (e.g., `P101`, `P2045`).
- Duplicate Product IDs appearing later in the batch are flagged as invalid to prevent double-counting inventory value.
- Unit price must be strictly positive (`> 0.0`), while stock quantity must be non-negative (`>= 0`, allowing out-of-stock `0`).
- Any valid item with `StockQty < reorder_threshold` requires a minimum replenishment order of `reorder_threshold - StockQty` units.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read `num_items` and `reorder_threshold`. Read `num_items` product lines and store `(prod_id, prod_name, price, qty)` tuples in `catalogue`.
- **Step 3:** Initialize `seen_ids = []`, `valid_items = []`, `invalid_records = []`, `replenish_items = []`, and `total_inventory_value = 0.0`.
- **Step 4:** For each tuple in `catalogue`, unpack `p_id, p_name, p_price, p_qty` and initialize `error_reason = ""`.
- **Step 5:** Check SKU format (`len >= 2`, `p_id[0] == "P"`, `p_id[1:].isdigit()`), duplicate `p_id in seen_ids`, `p_name != ""`, `p_price > 0`, and `p_qty >= 0`, appending any violations to `error_reason`.
- **Step 6:** If `error_reason != ""`, append tuple with `error_reason` to `invalid_records`.
- **Step 7:** Else append `p_id` to `seen_ids`, compute `item_value = p_price * p_qty`, add to `total_inventory_value`, and append to `valid_items`.
- **Step 8:** For valid items, if `p_qty < reorder_threshold`, append `(p_id, p_name, p_qty, reorder_threshold - p_qty)` to `replenish_items`.
- **Step 9:** Print validated valuation table, invalid record diagnostics, replenishment order list, and aggregate summary.
- **Step 10:** Stop the program.

---

## 5. Flowchart

![Flowchart - Tuple-Based Product Catalogue Audit](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT num_items, reorder_threshold
    SET catalogue = [], seen_ids = [], valid_items = [], invalid_records = [], replenish = []
    SET total_value = 0.0

    FOR i = 1 TO num_items DO
        INPUT p_id, p_name, p_price, p_qty
        APPEND (p_id, p_name, p_price, p_qty) TO catalogue
    END FOR

    FOR EACH item IN catalogue DO
        UNPACK p_id, p_name, p_price, p_qty FROM item
        SET err = ""
        IF NOT VALID_SKU(p_id) THEN CONCAT "Malformed ProductID; " TO err
        ELSE IF p_id IN seen_ids THEN CONCAT "Duplicate ProductID; " TO err END IF
        IF p_name == "" THEN CONCAT "Empty ProductName; " TO err END IF
        IF p_price <= 0 THEN CONCAT "Non-positive Price; " TO err END IF
        IF p_qty < 0 THEN CONCAT "Negative StockQty; " TO err END IF

        IF err != "" THEN
            APPEND (p_id, p_name, p_price, p_qty, err) TO invalid_records
        ELSE
            APPEND p_id TO seen_ids
            SET val = p_price * p_qty
            SET total_value = total_value + val
            APPEND (p_id, p_name, p_price, p_qty, val) TO valid_items
            IF p_qty < reorder_threshold THEN
                APPEND (p_id, p_name, p_qty, reorder_threshold - p_qty) TO replenish
            END IF
        END IF
    END FOR

    PRINT valid_items, invalid_records, replenish, total_value
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 10 (PDF #49): Tuple-Based Product Catalogue Audit
# Syllabus Concepts: Tuples, Tuple Operations, Unpacking, Lists, Loops, Conditionals, Operators

num_items = int(input("Enter number of catalogue records: "))
reorder_threshold = int(input("Enter minimum stock reorder threshold: "))

catalogue = []
for i in range(num_items):
    raw = input("Enter ProductID,ProductName,UnitPrice,StockQty: ").strip()
    parts = raw.split(",")
    prod_id = parts[0].strip()
    prod_name = parts[1].strip()
    price = float(parts[2].strip())
    qty = int(parts[3].strip())

    # Store each product record as a tuple
    catalogue.append((prod_id, prod_name, price, qty))

seen_ids = []
valid_items = []
invalid_records = []
replenish_items = []
total_inventory_value = 0.0

for item in catalogue:
    # Unpack product tuple
    p_id, p_name, p_price, p_qty = item
    error_reason = ""

    # Validate Product ID format (must start with 'P' followed by digits, e.g., P101)
    if len(p_id) < 2 or p_id[0] != "P" or not p_id[1:].isdigit():
        error_reason = error_reason + "Malformed ProductID; "
    elif p_id in seen_ids:
        error_reason = error_reason + "Duplicate ProductID; "

    if p_name == "":
        error_reason = error_reason + "Empty ProductName; "
    if p_price <= 0:
        error_reason = error_reason + "Non-positive Price; "
    if p_qty < 0:
        error_reason = error_reason + "Negative StockQty; "

    if error_reason != "":
        invalid_records.append((p_id, p_name, p_price, p_qty, error_reason[:-2]))
    else:
        seen_ids.append(p_id)
        item_value = p_price * p_qty
        total_inventory_value = total_inventory_value + item_value
        valid_items.append((p_id, p_name, p_price, p_qty, item_value))

        if p_qty < reorder_threshold:
            shortfall = reorder_threshold - p_qty
            replenish_items.append((p_id, p_name, p_qty, shortfall))

print("\n======================================================================")
print("               TUPLE-BASED PRODUCT CATALOGUE AUDIT                    ")
print("======================================================================")
print("VALIDATED INVENTORY VALUATION:")
if len(valid_items) == 0:
    print("No valid product records found.")
else:
    for v_item in valid_items:
        p_id, p_name, p_price, p_qty, val = v_item
        print(p_id, "|", format(p_name, "<16s"), "| Price: Rs.", format(p_price, "8.2f"), "| Stock:", format(p_qty, "4d"), "| Value: Rs.", format(val, "10.2f"))

print("----------------------------------------------------------------------")
print("INVALID CATALOGUE RECORDS FLAGGED:")
if len(invalid_records) == 0:
    print("None")
else:
    for bad_item in invalid_records:
        p_id, p_name, p_price, p_qty, err = bad_item
        print(" ->", p_id, "|", p_name, "| Price:", p_price, "| Qty:", p_qty, "| Issue:", err)

print("----------------------------------------------------------------------")
print("ITEMS REQUIRING REPLENISHMENT (Stock <", str(reorder_threshold) + "):")
if len(replenish_items) == 0:
    print("All valid products meet minimum stock threshold.")
else:
    for rep in replenish_items:
        p_id, p_name, cur_q, needed = rep
        print(" ->", p_id, "|", p_name, "| Current Stock:", cur_q, "| Minimum Order Needed:", needed, "units")

print("----------------------------------------------------------------------")
print("Valid Products:", len(valid_items), "| Invalid Records:", len(invalid_records), "| Total Inventory Value: Rs.", format(total_inventory_value, ".2f"))
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | Mixed warehouse feed with valid SKUs, malformed ID, duplicate SKU, and low stock | `5<br>15<br>P101,Wireless Mouse,650,25<br>P102,Mechanical KB,2400,8<br>X999,Invalid Cable,199,30<br>P101,Duplicate Mouse,650,10<br>P105,USB-C Hub,1250,4` | Values 3 valid SKUs at Rs. 40450.00, isolates X999 & duplicate P101, and flags P102 (need 7) & P105 (need 11) for reorder. | PASS |
| **TC-02** (Boundary / Tie) | Out-of-stock zero quantity (valid) vs exact reorder threshold stock | `2<br>10<br>P201,HDMI Adapter,450,0<br>P202,Laptop Stand,1500,10` | Treats Stock=0 as valid Rs. 0.00 valuation needing 10 units; Stock=10 meets threshold 10 without replenishment alert. | PASS |
| **TC-03** (Edge / Validation) | Compound invalid record with negative price and negative stock quantity | `2<br>10<br>P301,Webcam,-899,-5<br>P3A,Monitor,12000,5` | Rejects both records (compound Non-positive Price + Negative StockQty on P301; non-digit suffix on P3A); Total Value = Rs. 0.00. | PASS |

---

## 9. Output Screenshots

### TC-01: Mixed warehouse feed with valid SKUs, malformed ID, duplicate SKU, and low stock (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter number of catalogue records: 5
Enter minimum stock reorder threshold: 15
Enter ProductID,ProductName,UnitPrice,StockQty: P101,Wireless Mouse,650,25
Enter ProductID,ProductName,UnitPrice,StockQty: P102,Mechanical KB,2400,8
Enter ProductID,ProductName,UnitPrice,StockQty: X999,Invalid Cable,199,30
Enter ProductID,ProductName,UnitPrice,StockQty: P101,Duplicate Mouse,650,10
Enter ProductID,ProductName,UnitPrice,StockQty: P105,USB-C Hub,1250,4

======================================================================
               TUPLE-BASED PRODUCT CATALOGUE AUDIT                    
======================================================================
VALIDATED INVENTORY VALUATION:
P101 | Wireless Mouse   | Price: Rs.   650.00 | Stock:   25 | Value: Rs.   16250.00
P102 | Mechanical KB    | Price: Rs.  2400.00 | Stock:    8 | Value: Rs.   19200.00
P105 | USB-C Hub        | Price: Rs.  1250.00 | Stock:    4 | Value: Rs.    5000.00
----------------------------------------------------------------------
INVALID CATALOGUE RECORDS FLAGGED:
 -> X999 | Invalid Cable | Price: 199.0 | Qty: 30 | Issue: Malformed ProductID
 -> P101 | Duplicate Mouse | Price: 650.0 | Qty: 10 | Issue: Duplicate ProductID
----------------------------------------------------------------------
ITEMS REQUIRING REPLENISHMENT (Stock < 15):
 -> P102 | Mechanical KB | Current Stock: 8 | Minimum Order Needed: 7 units
 -> P105 | USB-C Hub | Current Stock: 4 | Minimum Order Needed: 11 units
----------------------------------------------------------------------
Valid Products: 3 | Invalid Records: 2 | Total Inventory Value: Rs. 40450.00
======================================================================
```
</details>

### TC-02: Out-of-stock zero quantity (valid) vs exact reorder threshold stock (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter number of catalogue records: 2
Enter minimum stock reorder threshold: 10
Enter ProductID,ProductName,UnitPrice,StockQty: P201,HDMI Adapter,450,0
Enter ProductID,ProductName,UnitPrice,StockQty: P202,Laptop Stand,1500,10

======================================================================
               TUPLE-BASED PRODUCT CATALOGUE AUDIT                    
======================================================================
VALIDATED INVENTORY VALUATION:
P201 | HDMI Adapter     | Price: Rs.   450.00 | Stock:    0 | Value: Rs.       0.00
P202 | Laptop Stand     | Price: Rs.  1500.00 | Stock:   10 | Value: Rs.   15000.00
----------------------------------------------------------------------
INVALID CATALOGUE RECORDS FLAGGED:
None
----------------------------------------------------------------------
ITEMS REQUIRING REPLENISHMENT (Stock < 10):
 -> P201 | HDMI Adapter | Current Stock: 0 | Minimum Order Needed: 10 units
----------------------------------------------------------------------
Valid Products: 2 | Invalid Records: 0 | Total Inventory Value: Rs. 15000.00
======================================================================
```
</details>

### TC-03: Compound invalid record with negative price and negative stock quantity (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter number of catalogue records: 2
Enter minimum stock reorder threshold: 10
Enter ProductID,ProductName,UnitPrice,StockQty: P301,Webcam,-899,-5
Enter ProductID,ProductName,UnitPrice,StockQty: P3A,Monitor,12000,5

======================================================================
               TUPLE-BASED PRODUCT CATALOGUE AUDIT                    
======================================================================
VALIDATED INVENTORY VALUATION:
No valid product records found.
----------------------------------------------------------------------
INVALID CATALOGUE RECORDS FLAGGED:
 -> P301 | Webcam | Price: -899.0 | Qty: -5 | Issue: Non-positive Price; Negative StockQty
 -> P3A | Monitor | Price: 12000.0 | Qty: 5 | Issue: Malformed ProductID
----------------------------------------------------------------------
ITEMS REQUIRING REPLENISHMENT (Stock < 10):
All valid products meet minimum stock threshold.
----------------------------------------------------------------------
Valid Products: 0 | Invalid Records: 2 | Total Inventory Value: Rs. 0.00
======================================================================
```
</details>

---

## 10. Conclusion

Tuple-Based Product Catalogue Audit demonstrates end-to-end data hygiene, combining string validation, duplicate detection via membership operators, tuple unpacking, financial valuation, and automated reorder computation.
