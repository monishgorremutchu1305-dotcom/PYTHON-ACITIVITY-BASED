# Case Study 04 (PDF #27): Advanced Numeric Pattern Generator


**Assigned Syllabus Concepts Used:** Pattern Generation, Nested Loops, Dimension Validation, String Formatting

---

## 1. Problem Statement

> **PDF Prompt (#27):** 27. Advanced Numeric Pattern Generator: Produce a hollow diamond or symmetric numerical pattern based on user-specified dimensions, with validation for invalid dimensions and carefully aligned output.

Geometric pattern generation exercises spatial reasoning, index-to-coordinate mapping, and nested loop control. Given a pattern mode (`HOLLOW` or `SYMMETRIC`) and a grid dimension `N`, the program must validate that `N` is an odd integer within a safe display bound (`3 <= N <= 19`) so a true center apex exists, and then render either a hollow numeric diamond or a palindromic symmetric numerical diamond (`1 2 ... k ... 2 1`) with fixed-width 3-character cells so two-digit levels align without distortion.

---

## 2. Objectives

1. Validate user-specified pattern mode and odd dimension bounds before entering nested rendering loops.
2. Compute mirror-symmetric row levels around `mid = (N // 2) + 1` using conditional coordinate reflection.
3. Construct fixed-width 3-character cells (`format(num, "2d") + " "`) so single- and double-digit numbers align in crisp vertical columns.
4. Support both `HOLLOW` boundary rendering and `SYMMETRIC` palindromic numeric fill within a unified nested-loop structure.

---

## 3. Assumptions

- Valid pattern modes are `HOLLOW` and `SYMMETRIC` (case-insensitive input normalized via `.upper()`).
- Dimension `N` must be an odd integer between 3 and 19 inclusive so the diamond has a symmetric horizontal midline.
- Each grid cell occupies exactly 3 characters (`2d` right-aligned number plus 1 trailing space, or 3 spaces for empty cells).
- Even dimensions, negative values, or unsupported modes trigger an immediate validation message without partial output.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read `mode` (convert to uppercase) and integer dimension `size`.
- **Step 3:** Validate `mode` in `("HOLLOW", "SYMMETRIC")` and `3 <= size <= 19` and `size % 2 == 1`. If invalid, print specific error message and jump to Step 9.
- **Step 4:** Compute `mid = (size // 2) + 1`.
- **Step 5:** Loop `row` from `1` to `size`: set `level = row` if `row <= mid` else `size - row + 1`.
- **Step 6:** Compute `leading_spaces = mid - level` and append `leading_spaces` blocks of `"   "` (3 spaces) to `line`.
- **Step 7:** Compute `width = (2 * level) - 1`. Loop `col` from `1` to `width`: if `mode == "HOLLOW"`, print `level` at `col == 1` or `col == width` and `"   "` inside; else compute palindromic value `num = col` (`col <= level`) or `(2 * level) - col` and format to 3 chars.
- **Step 8:** Print right-trimmed `line` for each `row`.
- **Step 9:** Stop the program.

---

## 5. Flowchart

![Flowchart - Advanced Numeric Pattern Generator](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT mode, size
    IF mode NOT IN ("HOLLOW", "SYMMETRIC") THEN
        PRINT "Validation Error: Invalid Mode"
    ELSE IF size < 3 OR size > 19 OR size MOD 2 == 0 THEN
        PRINT "Validation Error: Dimension N must be odd between 3 and 19"
    ELSE
        SET mid = (size DIV 2) + 1
        FOR row = 1 TO size DO
            IF row <= mid THEN level = row ELSE level = size - row + 1 END IF
            SET line = REPEAT("   ", mid - level)
            SET width = (2 * level) - 1

            FOR col = 1 TO width DO
                IF mode == "HOLLOW" THEN
                    IF col == 1 OR col == width THEN
                        CONCAT FORMAT(level, "2d") + " " TO line
                    ELSE
                        CONCAT "   " TO line
                    END IF
                ELSE
                    IF col <= level THEN num = col ELSE num = (2 * level) - col END IF
                    CONCAT FORMAT(num, "2d") + " " TO line
                END IF
            END FOR
            PRINT RSTRIP(line)
        END FOR
    END IF
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 4 (PDF #27): Advanced Numeric Pattern Generator
# Syllabus Concepts: Pattern Generation, Nested Loops, Conditionals, Strings, Alignment

mode = input("Enter Pattern Mode (HOLLOW / SYMMETRIC): ").strip().upper()
size = int(input("Enter odd dimension N (3 to 19): "))

print("\n======================================================================")
print("                ADVANCED NUMERIC PATTERN GENERATOR                    ")
print("======================================================================")

if mode != "HOLLOW" and mode != "SYMMETRIC":
    print("Validation Error: Mode must be either HOLLOW or SYMMETRIC.")
elif size < 3 or size > 19 or size % 2 == 0:
    print("Validation Error: Dimension N must be an odd integer between 3 and 19.")
else:
    mid = (size // 2) + 1
    print("Mode:", mode, "| Dimension:", str(size) + "x" + str(size), "| Apex Level:", mid)
    print("----------------------------------------------------------------------")

    for row in range(1, size + 1):
        if row <= mid:
            level = row
        else:
            level = size - row + 1

        leading_spaces = mid - level
        line = ""

        # Leading spaces for careful multi-digit alignment (3 chars per cell)
        for s in range(leading_spaces):
            line = line + "   "

        width = (2 * level) - 1
        for col in range(1, width + 1):
            if mode == "HOLLOW":
                if col == 1 or col == width:
                    val_str = format(level, "2d") + " "
                    line = line + val_str
                else:
                    line = line + "   "
            else:
                # SYMMETRIC palindromic numerical diamond: 1 2 .. level .. 2 1
                if col <= level:
                    num = col
                else:
                    num = (2 * level) - col
                val_str = format(num, "2d") + " "
                line = line + val_str

        print(line.rstrip())

    print("----------------------------------------------------------------------")
    print("Pattern generation completed successfully.")
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | 7x7 Symmetric Palindromic Numerical Diamond | `SYMMETRIC<br>7` | Renders a centered 7-row palindromic diamond peaking at 1 2 3 4 3 2 1 on row 4. | PASS |
| **TC-02** (Boundary / Tie) | 7x7 Hollow Numerical Diamond testing interior blank spacing | `HOLLOW<br>7` | Renders exterior vertices only (1 at apexes, 2..4 along outer edges) with exact interior hollow alignment. | PASS |
| **TC-03** (Edge / Validation) | Even dimension N = 8 rejected by odd-symmetry guard | `HOLLOW<br>8` | Rejects even dimension N=8 with clear validation error message. | PASS |

---

## 9. Output Screenshots

### TC-01: 7x7 Symmetric Palindromic Numerical Diamond (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter Pattern Mode (HOLLOW / SYMMETRIC): SYMMETRIC
Enter odd dimension N (3 to 19): 7

======================================================================
                ADVANCED NUMERIC PATTERN GENERATOR                    
======================================================================
Mode: SYMMETRIC | Dimension: 7x7 | Apex Level: 4
----------------------------------------------------------------------
          1
       1  2  1
    1  2  3  2  1
 1  2  3  4  3  2  1
    1  2  3  2  1
       1  2  1
          1
----------------------------------------------------------------------
Pattern generation completed successfully.
======================================================================
```
</details>

### TC-02: 7x7 Hollow Numerical Diamond testing interior blank spacing (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter Pattern Mode (HOLLOW / SYMMETRIC): HOLLOW
Enter odd dimension N (3 to 19): 7

======================================================================
                ADVANCED NUMERIC PATTERN GENERATOR                    
======================================================================
Mode: HOLLOW | Dimension: 7x7 | Apex Level: 4
----------------------------------------------------------------------
          1
       2     2
    3           3
 4                 4
    3           3
       2     2
          1
----------------------------------------------------------------------
Pattern generation completed successfully.
======================================================================
```
</details>

### TC-03: Even dimension N = 8 rejected by odd-symmetry guard (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter Pattern Mode (HOLLOW / SYMMETRIC): HOLLOW
Enter odd dimension N (3 to 19): 8

======================================================================
                ADVANCED NUMERIC PATTERN GENERATOR                    
======================================================================
Validation Error: Dimension N must be an odd integer between 3 and 19.
======================================================================
```
</details>

---

## 10. Conclusion

Advanced Numeric Pattern Generator illustrates coordinate symmetry, nested loop control, input domain validation, and fixed-width cell formatting to maintain geometric alignment across single- and double-digit numbers.
