# Case Study 3 (PDF #13): ATM Transaction Sequence Simulation
# Syllabus Concepts: Variables, Loops, Conditionals, Operators, Lists, Tuples, Unpacking

account_no = input("Enter Account Number: ").strip()
balance = float(input("Enter Opening Balance: "))
num_txns = int(input("Enter number of transactions: "))

min_balance = 500.0
per_txn_limit = 20000.0
daily_withdrawal_limit = 40000.0

daily_withdrawn = 0.0
total_deposited = 0.0
approved_count = 0
rejected_count = 0
ledger = []

for step in range(1, num_txns + 1):
    raw = input("Enter TxnType(D/W),Amount: ").strip()
    parts = raw.split(",")
    txn_type = parts[0].strip().upper()
    amount = float(parts[1].strip())

    status = "APPROVED"
    remark = "Completed"

    if txn_type != "D" and txn_type != "W":
        status = "REJECTED"
        remark = "Invalid Transaction Type"
    elif amount <= 0:
        status = "REJECTED"
        remark = "Amount Must Be Positive"
    elif txn_type == "D":
        balance = balance + amount
        total_deposited = total_deposited + amount
        approved_count = approved_count + 1
    elif txn_type == "W":
        if int(amount) != amount or int(amount) % 100 != 0:
            status = "REJECTED"
            remark = "Not Multiple of 100"
        elif amount > per_txn_limit:
            status = "REJECTED"
            remark = "Exceeds Per-Txn Limit (20000)"
        elif daily_withdrawn + amount > daily_withdrawal_limit:
            status = "REJECTED"
            remark = "Exceeds Daily Limit (40000)"
        elif balance - amount < min_balance:
            status = "REJECTED"
            remark = "Minimum Balance (500) Violation"
        else:
            balance = balance - amount
            daily_withdrawn = daily_withdrawn + amount
            approved_count = approved_count + 1

    if status == "REJECTED":
        rejected_count = rejected_count + 1

    ledger.append((step, txn_type, amount, status, balance, remark))

print("\n======================================================================")
print("                 ATM TRANSACTION SEQUENCE SUMMARY                     ")
print("======================================================================")
print("Account:", account_no, "| Min Bal Rule: Rs. 500.00 | Daily W/D Cap: Rs. 40000.00")
print("----------------------------------------------------------------------")

for entry in ledger:
    t_no, t_type, amt, stat, bal_after, note = entry
    label = "DEPOSIT "
    if t_type == "W":
        label = "WITHDRAW"
    elif t_type != "D":
        label = "UNKNOWN "
    print("#" + str(t_no), "|", label, "| Rs.", format(amt, "8.2f"), "|", stat, "| Bal: Rs.", format(bal_after, "9.2f"), "|", note)

print("----------------------------------------------------------------------")
print("Approved Transactions :", approved_count, "| Rejected Transactions :", rejected_count)
print("Total Deposited       : Rs.", format(total_deposited, ".2f"))
print("Total Withdrawn       : Rs.", format(daily_withdrawn, ".2f"))
print("Closing Balance       : Rs.", format(balance, ".2f"))
print("======================================================================")
