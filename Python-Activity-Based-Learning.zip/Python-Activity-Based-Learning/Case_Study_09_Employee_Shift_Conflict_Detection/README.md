# Case Study 09 (PDF #48): Tuple-Based Employee Shift Conflict Detection


**Assigned Syllabus Concepts Used:** Tuples & Unpacking, Interval Overlap Logic, Pairwise Nested Loops, Time Range Validation

---

## 1. Problem Statement

> **PDF Prompt (#48):** 48. Tuple-Based Employee Shift Conflict Detection: Represent employee shifts as tuples, compare time intervals, detect overlapping assignments, and identify employees with conflicting schedules.

Hospital, retail, and campus operations assign staff across multiple daily shift rosters. Double-booking an employee on overlapping shifts on the same day causes operational disruption. Representing each shift assignment as a 6-tuple `(shift_id, emp_id, emp_name, day, start_hr, end_hr)`, the program validates 24-hour intervals (`0 <= start_hr < end_hr <= 24`), performs pairwise interval comparison (`max(s1, s2) < min(e1, e2)`) while permitting back-to-back shifts (`e1 == s2`), and lists all conflicting pairs and affected employees.

---

## 2. Objectives

1. Model shift assignments as immutable 6-element tuples and unpack fields cleanly during validation and comparison.
2. Validate 24-hour shift boundaries (`0 <= start < end <= 24`), isolating malformed time intervals before conflict detection.
3. Detect true temporal overlaps on the same employee and weekday using `max(start1, start2) < min(end1, end2)` in nested loops.
4. Distinguish non-conflicting back-to-back handovers (`end1 == start2`) from genuine overlapping hours and summarize affected staff.

---

## 3. Assumptions

- Shift times are specified on a 24-hour decimal clock (`0.0` to `24.0`, e.g., `12.5` represents 12:30).
- A shift with `start_hr < 0`, `end_hr > 24`, or `start_hr >= end_hr` is rejected as an invalid time interval.
- Two valid shifts for the same `emp_id` on the same `day` conflict if and only if `max(s1, s2) < min(e1, e2)`.
- Back-to-back shifts where `end_hr_1 == start_hr_2` (e.g., `09:00–13:00` followed by `13:00–18:00`) have 0 overlap and are valid.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read `num_shifts` and initialize `valid_shifts = []` and `invalid_shifts = []`.
- **Step 3:** Loop `num_shifts` times: read `shift_id, emp_id, emp_name, day, start_hr, end_hr` and pack into `shift_tuple`.
- **Step 4:** If `start_hr < 0` or `end_hr > 24` or `start_hr >= end_hr`, append to `invalid_shifts`; else append to `valid_shifts`.
- **Step 5:** Initialize `conflicts = []` and `conflicted_employees = []`.
- **Step 6:** Outer loop `i` from `0` to `len(valid_shifts) - 1`; inner loop `j` from `i + 1` to `len(valid_shifts) - 1`: unpack both shift tuples.
- **Step 7:** If `eid1 == eid2` and `day1 == day2`, compute `overlap_start = max(s1, s2)` and `overlap_end = min(e1, e2)`.
- **Step 8:** If `overlap_start < overlap_end`, record conflict tuple with overlap duration `overlap_end - overlap_start` and add unique employee identifier to `conflicted_employees`.
- **Step 9:** Print invalid intervals, pairwise overlap details, and unique list of employees with conflicting schedules.
- **Step 10:** Stop the program.

---

## 5. Flowchart

![Flowchart - Tuple-Based Employee Shift Conflict Detection](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT num_shifts
    SET valid_shifts = [], invalid_shifts = [], conflicts = [], conflicted_emps = []

    FOR i = 1 TO num_shifts DO
        INPUT sid, eid, ename, day, start_hr, end_hr
        SET t = (sid, eid, ename, UPPER(day), start_hr, end_hr)
        IF start_hr < 0 OR end_hr > 24 OR start_hr >= end_hr THEN
            APPEND t TO invalid_shifts
        ELSE
            APPEND t TO valid_shifts
        END IF
    END FOR

    FOR i = 0 TO LENGTH(valid_shifts) - 1 DO
        UNPACK sid1, eid1, ename1, day1, s1, e1 FROM valid_shifts[i]
        FOR j = i + 1 TO LENGTH(valid_shifts) - 1 DO
            UNPACK sid2, eid2, ename2, day2, s2, e2 FROM valid_shifts[j]
            IF eid1 == eid2 AND day1 == day2 THEN
                SET ov_start = MAX(s1, s2), ov_end = MIN(e1, e2)
                IF ov_start < ov_end THEN
                    APPEND (eid1, ename1, day1, sid1, sid2, ov_end - ov_start) TO conflicts
                    IF eid1 NOT IN conflicted_emps THEN APPEND eid1 TO conflicted_emps END IF
                END IF
            END IF
        END FOR
    END FOR

    PRINT invalid_shifts, conflicts, conflicted_emps
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 9 (PDF #48): Tuple-Based Employee Shift Conflict Detection
# Syllabus Concepts: Tuples, Tuple Operations, Unpacking, Nested Loops, Conditionals, Lists

num_shifts = int(input("Enter number of shift assignments: "))
valid_shifts = []
invalid_shifts = []

for i in range(num_shifts):
    raw = input("Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: ").strip()
    parts = raw.split(",")
    shift_id = parts[0].strip()
    emp_id = parts[1].strip()
    emp_name = parts[2].strip()
    day = parts[3].strip().upper()
    start_hr = float(parts[4].strip())
    end_hr = float(parts[5].strip())

    shift_tuple = (shift_id, emp_id, emp_name, day, start_hr, end_hr)

    if start_hr < 0 or end_hr > 24 or start_hr >= end_hr:
        invalid_shifts.append(shift_tuple)
    else:
        valid_shifts.append(shift_tuple)

conflicts = []
conflicted_employees = []

# Compare pairs of valid shifts using nested loops and tuple unpacking
v_len = len(valid_shifts)
for i in range(v_len):
    sid1, eid1, ename1, day1, s1, e1 = valid_shifts[i]
    for j in range(i + 1, v_len):
        sid2, eid2, ename2, day2, s2, e2 = valid_shifts[j]

        # Same employee on the same day with overlapping interval: max(s1, s2) < min(e1, e2)
        if eid1 == eid2 and day1 == day2:
            overlap_start = s1
            if s2 > overlap_start:
                overlap_start = s2
            overlap_end = e1
            if e2 < overlap_end:
                overlap_end = e2

            if overlap_start < overlap_end:
                conflicts.append((eid1, ename1, day1, sid1, s1, e1, sid2, s2, e2, overlap_end - overlap_start))
                emp_tag = eid1 + " (" + ename1 + ")"
                if emp_tag not in conflicted_employees:
                    conflicted_employees.append(emp_tag)

print("\n======================================================================")
print("          TUPLE-BASED EMPLOYEE SHIFT CONFLICT DETECTION               ")
print("======================================================================")
print("Total Records:", num_shifts, "| Valid Shifts:", len(valid_shifts), "| Invalid Time Ranges:", len(invalid_shifts))

if len(invalid_shifts) > 0:
    print("----------------------------------------------------------------------")
    print("INVALID SHIFT INTERVALS REJECTED:")
    for bad in invalid_shifts:
        sid, eid, ename, day, sh, eh = bad
        print(" ->", sid, "|", eid, ename, "|", day, "|", format(sh, ".1f"), "to", format(eh, ".1f"), "(Invalid Hours)")

print("----------------------------------------------------------------------")
print("OVERLAPPING SHIFT CONFLICTS DETECTED:")
if len(conflicts) == 0:
    print("No overlapping employee shift assignments detected.")
else:
    for c_rec in conflicts:
        eid, ename, day, sid1, s1, e1, sid2, s2, e2, ov_hrs = c_rec
        print("Conflict:", eid, ename, "on", day, "|", sid1 + "(" + format(s1, ".1f") + "-" + format(e1, ".1f") + ") overlaps", sid2 + "(" + format(s2, ".1f") + "-" + format(e2, ".1f") + ") by", format(ov_hrs, ".1f"), "hrs")

print("----------------------------------------------------------------------")
if len(conflicted_employees) == 0:
    print("Employees With Conflicting Schedules: None")
else:
    emp_summary = ""
    for k in range(len(conflicted_employees)):
        if k > 0:
            emp_summary = emp_summary + ", "
        emp_summary = emp_summary + conflicted_employees[k]
    print("Employees With Conflicting Schedules:", emp_summary)
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | Overlap vs valid back-to-back shift vs inverted invalid time range | `5<br>S101,E01,Vikram,MON,9,14<br>S102,E01,Vikram,MON,12.5,17<br>S103,E02,Priya,MON,9,13<br>S104,E02,Priya,MON,13,18<br>S105,E03,Rahul,TUE,16,12` | Flags S105 (16 to 12) as invalid, permits Priya back-to-back (9-13 & 13-18), and detects 1.5 hr overlap for E01 Vikram on MON. | PASS |
| **TC-02** (Boundary / Tie) | Clean conflict-free roster across same hours on different days/employees | `3<br>S201,E10,Neha,WED,8,16<br>S202,E10,Neha,THU,8,16<br>S203,E11,Karan,WED,8,16` | All 3 shifts are valid with zero overlaps since identical hours belong either to different weekdays or different employees. | PASS |
| **TC-03** (Edge / Validation) | Three-way cascading overlap for single employee without duplicate roster listing | `3<br>S301,E07,Suresh,FRI,8,14<br>S302,E07,Suresh,FRI,10,16<br>S303,E07,Suresh,FRI,12,18` | Detects all 3 pairwise overlaps (S301-S302: 4.0h, S301-S303: 2.0h, S302-S303: 4.0h) while listing E07 (Suresh) once. | PASS |

---

## 9. Output Screenshots

### TC-01: Overlap vs valid back-to-back shift vs inverted invalid time range (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter number of shift assignments: 5
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S101,E01,Vikram,MON,9,14
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S102,E01,Vikram,MON,12.5,17
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S103,E02,Priya,MON,9,13
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S104,E02,Priya,MON,13,18
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S105,E03,Rahul,TUE,16,12

======================================================================
          TUPLE-BASED EMPLOYEE SHIFT CONFLICT DETECTION               
======================================================================
Total Records: 5 | Valid Shifts: 4 | Invalid Time Ranges: 1
----------------------------------------------------------------------
INVALID SHIFT INTERVALS REJECTED:
 -> S105 | E03 Rahul | TUE | 16.0 to 12.0 (Invalid Hours)
----------------------------------------------------------------------
OVERLAPPING SHIFT CONFLICTS DETECTED:
Conflict: E01 Vikram on MON | S101(9.0-14.0) overlaps S102(12.5-17.0) by 1.5 hrs
----------------------------------------------------------------------
Employees With Conflicting Schedules: E01 (Vikram)
======================================================================
```
</details>

### TC-02: Clean conflict-free roster across same hours on different days/employees (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter number of shift assignments: 3
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S201,E10,Neha,WED,8,16
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S202,E10,Neha,THU,8,16
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S203,E11,Karan,WED,8,16

======================================================================
          TUPLE-BASED EMPLOYEE SHIFT CONFLICT DETECTION               
======================================================================
Total Records: 3 | Valid Shifts: 3 | Invalid Time Ranges: 0
----------------------------------------------------------------------
OVERLAPPING SHIFT CONFLICTS DETECTED:
No overlapping employee shift assignments detected.
----------------------------------------------------------------------
Employees With Conflicting Schedules: None
======================================================================
```
</details>

### TC-03: Three-way cascading overlap for single employee without duplicate roster listing (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter number of shift assignments: 3
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S301,E07,Suresh,FRI,8,14
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S302,E07,Suresh,FRI,10,16
Enter ShiftID,EmpID,EmpName,Day,StartHour,EndHour: S303,E07,Suresh,FRI,12,18

======================================================================
          TUPLE-BASED EMPLOYEE SHIFT CONFLICT DETECTION               
======================================================================
Total Records: 3 | Valid Shifts: 3 | Invalid Time Ranges: 0
----------------------------------------------------------------------
OVERLAPPING SHIFT CONFLICTS DETECTED:
Conflict: E07 Suresh on FRI | S301(8.0-14.0) overlaps S302(10.0-16.0) by 4.0 hrs
Conflict: E07 Suresh on FRI | S301(8.0-14.0) overlaps S303(12.0-18.0) by 2.0 hrs
Conflict: E07 Suresh on FRI | S302(10.0-16.0) overlaps S303(12.0-18.0) by 4.0 hrs
----------------------------------------------------------------------
Employees With Conflicting Schedules: E07 (Suresh)
======================================================================
```
</details>

---

## 10. Conclusion

Tuple-Based Employee Shift Conflict Detection highlights the expressiveness of Python tuples and tuple unpacking for representing structured temporal intervals and executing `O(N^2)` pairwise conflict audits.
