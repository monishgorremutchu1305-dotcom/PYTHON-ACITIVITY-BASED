# Case Study 03 (PDF #13): ATM Transaction Sequence Simulation


**Assigned Syllabus Concepts Used:** State Loops, Guard Conditionals, Modulo & Comparison Operators, Tuple Ledger

---

## 1. Problem Statement

> **PDF Prompt (#13):** 13. ATM Transaction Sequence Simulation: Process a sequence of deposits and withdrawals, maintain a simulated balance, enforce withdrawal limits, reject invalid transactions, and produce a transaction summary.

Automated Teller Machines (ATMs) process sequential banking requests while strictly enforcing account invariants so an account balance never violates minimum reserve rules or daily cash-dispensing limits. Each transaction specifies an operation code (`D` for Deposit, `W` for Withdrawal) and an amount. Invalid codes, non-positive amounts, non-multiples of Rs. 100, per-transaction cap breaches, daily withdrawal limit breaches, and minimum-balance violations must be rejected cleanly without corrupting the running balance.

---

## 2. Objectives

1. Simulate stateful sequential processing of deposits and withdrawals across an ordered transaction stream.
2. Enforce cascading validation rules (denomination multiple of 100, Rs. 20,000 per-transaction limit, Rs. 40,000 cumulative daily cap, and Rs. 500 minimum balance).
3. Maintain an immutable audit trail of transaction tuples capturing step number, type, amount, decision status, post-transaction balance, and remark.
4. Generate a comprehensive reconciliation statement tallying approved/rejected counts, total inflows/outflows, and closing balance.

---

## 3. Assumptions

- Minimum mandatory account balance after any withdrawal is Rs. 500.00.
- ATM cash cassette dispenses currency notes in multiples of Rs. 100 only for withdrawals.
- Maximum single withdrawal is Rs. 20,000.00 and cumulative daily withdrawal limit is Rs. 40,000.00.
- Valid deposits (`D` > 0) immediately credit the available balance without denomination restrictions.
- Rejected transactions leave both running account balance and cumulative daily withdrawal unchanged.

---

## 4. Algorithm

- **Step 1:** Start the program.
- **Step 2:** Read `account_no`, initial `balance`, and `num_txns`. Initialize `daily_withdrawn = 0`, `total_deposited = 0`, `approved_count = 0`, `rejected_count = 0`, and `ledger = []`.
- **Step 3:** Loop `step` from 1 to `num_txns`: read `txn_type` and `amount`.
- **Step 4:** Validate `txn_type` in `("D", "W")` and `amount > 0`; if invalid, mark `REJECTED` with diagnostic remark.
- **Step 5:** If `txn_type == "D"`, add `amount` to `balance` and `total_deposited`, and increment `approved_count`.
- **Step 6:** If `txn_type == "W"`, verify: (a) `amount` is an integer multiple of 100, (b) `amount <= 20000`, (c) `daily_withdrawn + amount <= 40000`, and (d) `balance - amount >= 500`.
- **Step 7:** If all withdrawal checks pass, deduct `amount` from `balance`, add to `daily_withdrawn`, and increment `approved_count`; else mark `REJECTED` with specific rule violated.
- **Step 8:** Append `(step, txn_type, amount, status, balance, remark)` to `ledger`.
- **Step 9:** Unpack and print all `ledger` entries followed by aggregate summary statistics and closing balance.
- **Step 10:** Stop the program.

---

## 5. Flowchart

![Flowchart - ATM Transaction Sequence Simulation](./flowchart.svg)

---

## 6. Pseudocode

```text
BEGIN
    INPUT account_no, balance, num_txns
    SET min_bal = 500, per_limit = 20000, daily_limit = 40000
    SET daily_withdrawn = 0, total_deposited = 0, approved = 0, rejected = 0, ledger = []

    FOR step = 1 TO num_txns DO
        INPUT txn_type, amount
        SET status = "APPROVED", remark = "Completed"

        IF txn_type NOT IN ("D", "W") OR amount <= 0 THEN
            SET status = "REJECTED", remark = "Invalid Type or Amount"
        ELSE IF txn_type == "D" THEN
            SET balance = balance + amount
            SET total_deposited = total_deposited + amount
            INCREMENT approved
        ELSE
            IF amount MOD 100 != 0 THEN SET status = "REJECTED", remark = "Not Multiple of 100"
            ELSE IF amount > per_limit THEN SET status = "REJECTED", remark = "Exceeds Per-Txn Limit"
            ELSE IF daily_withdrawn + amount > daily_limit THEN SET status = "REJECTED", remark = "Exceeds Daily Limit"
            ELSE IF balance - amount < min_bal THEN SET status = "REJECTED", remark = "Minimum Balance Violation"
            ELSE
                SET balance = balance - amount
                SET daily_withdrawn = daily_withdrawn + amount
                INCREMENT approved
            END IF
        END IF

        IF status == "REJECTED" THEN INCREMENT rejected END IF
        APPEND (step, txn_type, amount, status, balance, remark) TO ledger
    END FOR

    PRINT ledger, approved, rejected, total_deposited, daily_withdrawn, balance
END
```

---

## 7. Python Source Code (`solution.py`)

```python
# Case Study 3 (PDF #13): ATM Transaction Sequence Simulation
# Syllabus Concepts: Variables, Loops, Conditionals, Operators, Lists, Tuples, Unpacking

account_no = input("Enter Account Number: ").strip()
balance = float(input("Enter Opening Balance: "))
num_txns = int(input("Enter number of transactions: "))

min_balance = 500.0
per_txn_limit = 20000.0
daily_withdrawal_limit = 40000.0

daily_withdrawn = 0.0
total_deposited = 0.0
approved_count = 0
rejected_count = 0
ledger = []

for step in range(1, num_txns + 1):
    raw = input("Enter TxnType(D/W),Amount: ").strip()
    parts = raw.split(",")
    txn_type = parts[0].strip().upper()
    amount = float(parts[1].strip())

    status = "APPROVED"
    remark = "Completed"

    if txn_type != "D" and txn_type != "W":
        status = "REJECTED"
        remark = "Invalid Transaction Type"
    elif amount <= 0:
        status = "REJECTED"
        remark = "Amount Must Be Positive"
    elif txn_type == "D":
        balance = balance + amount
        total_deposited = total_deposited + amount
        approved_count = approved_count + 1
    elif txn_type == "W":
        if int(amount) != amount or int(amount) % 100 != 0:
            status = "REJECTED"
            remark = "Not Multiple of 100"
        elif amount > per_txn_limit:
            status = "REJECTED"
            remark = "Exceeds Per-Txn Limit (20000)"
        elif daily_withdrawn + amount > daily_withdrawal_limit:
            status = "REJECTED"
            remark = "Exceeds Daily Limit (40000)"
        elif balance - amount < min_balance:
            status = "REJECTED"
            remark = "Minimum Balance (500) Violation"
        else:
            balance = balance - amount
            daily_withdrawn = daily_withdrawn + amount
            approved_count = approved_count + 1

    if status == "REJECTED":
        rejected_count = rejected_count + 1

    ledger.append((step, txn_type, amount, status, balance, remark))

print("\n======================================================================")
print("                 ATM TRANSACTION SEQUENCE SUMMARY                     ")
print("======================================================================")
print("Account:", account_no, "| Min Bal Rule: Rs. 500.00 | Daily W/D Cap: Rs. 40000.00")
print("----------------------------------------------------------------------")

for entry in ledger:
    t_no, t_type, amt, stat, bal_after, note = entry
    label = "DEPOSIT "
    if t_type == "W":
        label = "WITHDRAW"
    elif t_type != "D":
        label = "UNKNOWN "
    print("#" + str(t_no), "|", label, "| Rs.", format(amt, "8.2f"), "|", stat, "| Bal: Rs.", format(bal_after, "9.2f"), "|", note)

print("----------------------------------------------------------------------")
print("Approved Transactions :", approved_count, "| Rejected Transactions :", rejected_count)
print("Total Deposited       : Rs.", format(total_deposited, ".2f"))
print("Total Withdrawn       : Rs.", format(daily_withdrawn, ".2f"))
print("Closing Balance       : Rs.", format(balance, ".2f"))
print("======================================================================")
```

---

## 8. Test Cases

| Test ID | Scenario | Sample Input (`stdin`) | Expected Behaviour | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** (Normal) | Mixed deposit and withdrawal stream testing per-txn cap and min-balance floor | `SB-90812<br>15000<br>5<br>D,10000<br>W,18000<br>W,25000<br>W,6600<br>W,5000` | Approves #1, #2, #5; rejects #3 (>20000 single cap) and #4 (7000-6600=400 < 500 min balance); closes at Rs. 2000.00. | PASS |
| **TC-02** (Boundary / Tie) | Cumulative Rs. 40,000 daily withdrawal limit enforcement across 3 withdrawals | `SB-55201<br>60000<br>3<br>W,20000<br>W,20000<br>W,500` | Approves two Rs. 20,000 withdrawals reaching exact Rs. 40,000 daily cap; rejects third Rs. 500 withdrawal. | PASS |
| **TC-03** (Edge / Validation) | Invalid transaction code, non-multiple of 100, and negative amount rejection | `SB-77100<br>5000<br>3<br>X,1000<br>W,1250<br>D,-500` | All 3 malformed requests are rejected cleanly with specific diagnostic messages; opening balance Rs. 5000.00 remains intact. | PASS |

---

## 9. Output Screenshots

### TC-01: Mixed deposit and withdrawal stream testing per-txn cap and min-balance floor (Normal)

![Output Screenshot TC-01](./screenshots/output_TC-01.png)

<details>
<summary>View Raw Terminal Transcript (TC-01)</summary>

```text
Enter Account Number: SB-90812
Enter Opening Balance: 15000
Enter number of transactions: 5
Enter TxnType(D/W),Amount: D,10000
Enter TxnType(D/W),Amount: W,18000
Enter TxnType(D/W),Amount: W,25000
Enter TxnType(D/W),Amount: W,6600
Enter TxnType(D/W),Amount: W,5000

======================================================================
                 ATM TRANSACTION SEQUENCE SUMMARY                     
======================================================================
Account: SB-90812 | Min Bal Rule: Rs. 500.00 | Daily W/D Cap: Rs. 40000.00
----------------------------------------------------------------------
#1 | DEPOSIT  | Rs. 10000.00 | APPROVED | Bal: Rs.  25000.00 | Completed
#2 | WITHDRAW | Rs. 18000.00 | APPROVED | Bal: Rs.   7000.00 | Completed
#3 | WITHDRAW | Rs. 25000.00 | REJECTED | Bal: Rs.   7000.00 | Exceeds Per-Txn Limit (20000)
#4 | WITHDRAW | Rs.  6600.00 | REJECTED | Bal: Rs.   7000.00 | Minimum Balance (500) Violation
#5 | WITHDRAW | Rs.  5000.00 | APPROVED | Bal: Rs.   2000.00 | Completed
----------------------------------------------------------------------
Approved Transactions : 3 | Rejected Transactions : 2
Total Deposited       : Rs. 10000.00
Total Withdrawn       : Rs. 23000.00
Closing Balance       : Rs. 2000.00
======================================================================
```
</details>

### TC-02: Cumulative Rs. 40,000 daily withdrawal limit enforcement across 3 withdrawals (Boundary / Tie)

![Output Screenshot TC-02](./screenshots/output_TC-02.png)

<details>
<summary>View Raw Terminal Transcript (TC-02)</summary>

```text
Enter Account Number: SB-55201
Enter Opening Balance: 60000
Enter number of transactions: 3
Enter TxnType(D/W),Amount: W,20000
Enter TxnType(D/W),Amount: W,20000
Enter TxnType(D/W),Amount: W,500

======================================================================
                 ATM TRANSACTION SEQUENCE SUMMARY                     
======================================================================
Account: SB-55201 | Min Bal Rule: Rs. 500.00 | Daily W/D Cap: Rs. 40000.00
----------------------------------------------------------------------
#1 | WITHDRAW | Rs. 20000.00 | APPROVED | Bal: Rs.  40000.00 | Completed
#2 | WITHDRAW | Rs. 20000.00 | APPROVED | Bal: Rs.  20000.00 | Completed
#3 | WITHDRAW | Rs.   500.00 | REJECTED | Bal: Rs.  20000.00 | Exceeds Daily Limit (40000)
----------------------------------------------------------------------
Approved Transactions : 2 | Rejected Transactions : 1
Total Deposited       : Rs. 0.00
Total Withdrawn       : Rs. 40000.00
Closing Balance       : Rs. 20000.00
======================================================================
```
</details>

### TC-03: Invalid transaction code, non-multiple of 100, and negative amount rejection (Edge / Validation)

![Output Screenshot TC-03](./screenshots/output_TC-03.png)

<details>
<summary>View Raw Terminal Transcript (TC-03)</summary>

```text
Enter Account Number: SB-77100
Enter Opening Balance: 5000
Enter number of transactions: 3
Enter TxnType(D/W),Amount: X,1000
Enter TxnType(D/W),Amount: W,1250
Enter TxnType(D/W),Amount: D,-500

======================================================================
                 ATM TRANSACTION SEQUENCE SUMMARY                     
======================================================================
Account: SB-77100 | Min Bal Rule: Rs. 500.00 | Daily W/D Cap: Rs. 40000.00
----------------------------------------------------------------------
#1 | UNKNOWN  | Rs.  1000.00 | REJECTED | Bal: Rs.   5000.00 | Invalid Transaction Type
#2 | WITHDRAW | Rs.  1250.00 | REJECTED | Bal: Rs.   5000.00 | Not Multiple of 100
#3 | DEPOSIT  | Rs.  -500.00 | REJECTED | Bal: Rs.   5000.00 | Amount Must Be Positive
----------------------------------------------------------------------
Approved Transactions : 0 | Rejected Transactions : 3
Total Deposited       : Rs. 0.00
Total Withdrawn       : Rs. 0.00
Closing Balance       : Rs. 5000.00
======================================================================
```
</details>

---

## 10. Conclusion

The ATM Transaction Sequence Simulation demonstrates state-machine integrity in Python using loops, ordered guard conditionals, modulo arithmetic, and tuple ledgers, guaranteeing that invalid operations never corrupt financial balances.
